"""One shared lab password. A successful login gets a signed, expiring cookie."""

import hashlib
import hmac
import secrets
import time
from typing import Optional

from fastapi import HTTPException, Request

COOKIE_NAME = "bioprinter_session"
SESSION_S = 12 * 60 * 60

# Sessions end when the server restarts, which is acceptable for a lab tool.
_secret = secrets.token_bytes(32)


def password_matches(given: str, expected: str) -> bool:
    return secrets.compare_digest(given.encode(), expected.encode())


def _sign(expires: str) -> str:
    return hmac.new(_secret, expires.encode(), hashlib.sha256).hexdigest()


def new_session() -> str:
    expires = str(int(time.time()) + SESSION_S)
    return f"{expires}.{_sign(expires)}"


def session_valid(token: Optional[str]) -> bool:
    if not token or "." not in token:
        return False
    expires, signature = token.split(".", 1)
    if not secrets.compare_digest(signature.encode(), _sign(expires).encode()):
        return False
    return expires.isdigit() and int(expires) > time.time()


def require_session(request: Request) -> None:
    if not session_valid(request.cookies.get(COOKIE_NAME)):
        raise HTTPException(status_code=401, detail="Please log in.")
