"""Settings, all read from environment variables so nothing is edited per machine."""

import os
from dataclasses import dataclass

# Limits from the pump Arduino sketch.
MAX_PRESSURE_MBAR = 2068
PUMP_CHANNELS = (0, 1, 2)
PUMP_BAUDRATE = 115200

DEV_PASSWORD = "bioprinter"


@dataclass(frozen=True)
class Settings:
    mode: str = "sim"                       # "sim" or "real"
    password: str = DEV_PASSWORD            # GUI login
    pump_port: str = "auto"                 # "auto", or a path such as /dev/ttyACM1
    duet_url: str = "http://192.168.2.1"
    duet_password: str = "reprap"           # RepRapFirmware's default
    max_purge_s: float = 300.0              # Limit for a purge with no duration
    log_dir: str = "logs"
    data_dir: str = "data"                  # Calibration results
    sync_script: str = ""                   # Script Quick Start runs
    sync_flow_rate: float = 0.0             # Passed as --flow-rate when above 0
    duet_usb_port: str = "auto"             # USB port the sync script reads markers from
    dwc_url: str = ""                       # Link to Duet Web Control


def load_settings() -> Settings:
    mode = os.environ.get("BIOPRINTER_MODE", "sim").lower()
    if mode not in ("sim", "real"):
        raise SystemExit("BIOPRINTER_MODE must be 'sim' or 'real'.")

    password = os.environ.get("BIOPRINTER_PASSWORD", "")
    if not password:
        if mode == "real":
            raise SystemExit("Set BIOPRINTER_PASSWORD before running with real hardware.")
        password = DEV_PASSWORD

    return Settings(
        mode=mode,
        password=password,
        pump_port=os.environ.get("PUMP_PORT", "auto"),
        duet_url=os.environ.get("DUET_URL", Settings.duet_url).rstrip("/"),
        duet_password=os.environ.get("DUET_PASSWORD", Settings.duet_password),
        max_purge_s=float(os.environ.get("MAX_PURGE_S", Settings.max_purge_s)),
        log_dir=os.environ.get("BIOPRINTER_LOG_DIR", Settings.log_dir),
        data_dir=os.environ.get("BIOPRINTER_DATA_DIR", Settings.data_dir),
        sync_script=os.environ.get("SYNC_SCRIPT", ""),
        sync_flow_rate=float(os.environ.get("SYNC_FLOW_RATE", 0)),
        duet_usb_port=os.environ.get("DUET_USB_PORT", "auto"),
        dwc_url=os.environ.get("DWC_URL", ""),
    )
