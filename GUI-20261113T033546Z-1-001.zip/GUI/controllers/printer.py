"""Duet 3 access through the RepRapFirmware HTTP API (rr_ endpoints).

https://github.com/Duet3D/RepRapFirmware/wiki/HTTP-requests
Not yet tested against a real board.
"""

import time

import requests

TIMEOUT_S = 3.0
REPLY_WAIT_S = 2.0
TRANSFER_TIMEOUT_S = (3.0, 300.0)  # Connecting, then moving a whole file
GCODE_DIR = "0:/gcodes"

EMPTY_STATUS = {"connected": False, "status": "unknown", "file": None, "position": None, "error": None}


class PrinterError(Exception):
    pass


class DuetClient:
    def __init__(self, base_url: str, password: str):
        self._base = base_url
        self._password = password
        self._http = requests.Session()
        self._has_session = False

    def _get(self, path: str, timeout=TIMEOUT_S, missing_ok=False, **params):
        if not self._has_session:
            self._connect()
        try:
            response = self._http.get(f"{self._base}/{path}", params=params, timeout=timeout)
            if response.status_code == 401:  # Session timed out
                self._connect()
                response = self._http.get(f"{self._base}/{path}", params=params, timeout=timeout)
            if missing_ok and response.status_code == 404:
                return None
            response.raise_for_status()
            return response
        except requests.RequestException as exc:
            self._has_session = False
            raise PrinterError(f"Duet request failed: {exc}") from exc

    def _connect(self) -> None:
        try:
            response = self._http.get(
                f"{self._base}/rr_connect", params={"password": self._password}, timeout=TIMEOUT_S
            )
            response.raise_for_status()
            err = response.json().get("err")
        except (requests.RequestException, ValueError) as exc:
            raise PrinterError(f"Cannot reach Duet: {exc}") from exc
        if err == 1:
            raise PrinterError("Duet rejected the password.")
        if err != 0:
            raise PrinterError("Duet has no free sessions.")
        self._has_session = True

    def _model(self, key: str):
        return self._get("rr_model", key=key, flags="d99vno").json().get("result")

    def send_gcode(self, command: str) -> str:
        before = self._model("seqs.reply")
        self._get("rr_gcode", gcode=command)
        deadline = time.monotonic() + REPLY_WAIT_S
        while time.monotonic() < deadline:
            if self._model("seqs.reply") != before:
                return self._get("rr_reply").text.strip()
            time.sleep(0.1)
        return ""

    def list_files(self) -> dict:
        """Return {file name: size} for the Duet's G-code folder."""
        files = {}
        first = 0
        while True:
            result = self._get("rr_filelist", dir=GCODE_DIR, first=first).json()
            if result.get("err"):
                raise PrinterError(f"Duet could not list {GCODE_DIR} (error {result['err']}).")
            for entry in result.get("files", []):
                if entry.get("type") == "f":
                    files[entry["name"]] = entry["size"]
            first = result.get("next", 0)
            if not first:
                return files

    def upload_file(self, name: str, data: bytes, crc32: int) -> None:
        """Store a file on the Duet. The Duet refuses it if the CRC32 does not match."""
        params = {"name": f"{GCODE_DIR}/{name}", "crc32": f"{crc32:08x}"}
        url = f"{self._base}/rr_upload"
        if not self._has_session:
            self._connect()
        try:
            response = self._http.post(url, params=params, data=data, timeout=TRANSFER_TIMEOUT_S)
            if response.status_code == 401:
                self._connect()
                response = self._http.post(url, params=params, data=data, timeout=TRANSFER_TIMEOUT_S)
            response.raise_for_status()
            err = response.json().get("err")
        except (requests.RequestException, ValueError) as exc:
            self._has_session = False
            raise PrinterError(f"Upload to the Duet failed: {exc}") from exc
        if err != 0:
            raise PrinterError("The Duet rejected the upload, so the file may have been damaged in transit.")

    def download_file(self, name: str):
        """Return the file's bytes, or None if the Duet does not have it."""
        response = self._get(
            "rr_download", timeout=TRANSFER_TIMEOUT_S, missing_ok=True, name=f"{GCODE_DIR}/{name}"
        )
        return None if response is None else response.content

    def emergency_stop(self) -> None:
        self._get("rr_gcode", gcode="M112")

    def reset(self) -> None:
        self._get("rr_gcode", gcode="M999")

    def status(self) -> dict:
        axes = self._model("move.axes") or []
        position = {a.get("letter"): a.get("machinePosition") for a in axes}
        return {
            "connected": True,
            "status": self._model("state.status") or "unknown",
            "file": self._model("job.file.fileName"),
            "position": position or None,
            "error": None,
        }
