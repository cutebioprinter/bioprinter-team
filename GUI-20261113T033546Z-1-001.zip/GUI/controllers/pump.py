"""The only code that talks to the pump Arduino.

Holds the serial port open for the life of the server, because opening it resets
the Arduino, which also re-measures its zero-pressure baseline. Pressure timing
lives here and in services/operations.py, so it never depends on the browser.
"""

import math
import threading
import time
from typing import Callable, Optional

from serial.tools import list_ports

from config import MAX_PRESSURE_MBAR, PUMP_BAUDRATE, PUMP_CHANNELS

ARDUINO_USB_VIDS = {0x2341, 0x2A03, 0x1A86}  # Arduino, Arduino, CH340 clones
DUET_USB_VIDS = {0x1D50}

HANDSHAKE_TIMEOUT_S = 5.0   # Reset, baseline measurement, then first feedback line
FEEDBACK_STALE_S = 1.0      # The sketch sends feedback every 50 ms
FEEDBACK_LOST_S = 3.0       # Silent this long: reconnect
RECONNECT_DELAY_S = 2.0


class PumpError(Exception):
    pass


def encode_frame(channel: int, pressure: float) -> bytes:
    """Frame 0ccppppp 1ppppppp, decoded by loop() in the pump sketch."""
    channel = int(channel)
    if channel not in PUMP_CHANNELS:
        raise ValueError(f"Invalid pump channel: {channel}")
    if not math.isfinite(pressure):
        raise ValueError(f"Invalid pressure: {pressure}")
    pressure = max(0, min(MAX_PRESSURE_MBAR, int(pressure)))
    return bytes([(channel << 5) | ((pressure >> 7) & 0x1F), 0x80 | (pressure & 0x7F)])


def parse_feedback(line: bytes) -> Optional[list]:
    """Return the three gauge pressures in mbar, or None if the line is not valid."""
    try:
        values = [float(field) for field in line.decode("ascii").strip().split(",")]
    except (UnicodeDecodeError, ValueError):
        return None
    if len(values) != len(PUMP_CHANNELS) or not all(math.isfinite(v) for v in values):
        return None
    return values


def find_pump_port(requested: str = "auto", ports=None) -> str:
    """Return the port to open. Raises PumpError rather than guessing."""
    ports = list(list_ports.comports() if ports is None else ports)

    if requested != "auto":
        if any(p.device == requested and p.vid in DUET_USB_VIDS for p in ports):
            raise PumpError(f"{requested} is the Duet, not the pump.")
        return requested

    matches = [p for p in ports if p.vid in ARDUINO_USB_VIDS]
    if len(matches) == 1:
        return matches[0].device
    if matches:
        names = ", ".join(p.device for p in matches)
        raise PumpError(f"More than one Arduino found ({names}). Set PUMP_PORT.")
    raise PumpError("No Arduino found on USB.")


def find_duet_usb_port(requested: str = "auto", ports=None) -> str:
    """Return the Duet's USB serial port, which carries the M118 sync messages."""
    if requested != "auto":
        return requested
    ports = list(list_ports.comports() if ports is None else ports)
    matches = [p for p in ports if p.vid in DUET_USB_VIDS]
    if len(matches) == 1:
        return matches[0].device
    raise PumpError("Could not identify the Duet on USB. Set DUET_USB_PORT.")


class PumpController:
    def __init__(self, opener: Callable[[], object], log):
        self._opener = opener
        self._log = log
        self._lock = threading.Lock()
        self._ser = None
        self._ready = False
        self._closing = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._measured = [0.0] * len(PUMP_CHANNELS)
        self._commanded = [0] * len(PUMP_CHANNELS)
        self._last_feedback = 0.0
        self._error: Optional[str] = None
        self._last_logged_error: Optional[str] = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, name="pump", daemon=True)
        self._thread.start()

    def close(self) -> None:
        self._closing.set()
        if self._thread:
            self._thread.join(timeout=3)
        self._drop_port()

    @property
    def connected(self) -> bool:
        return self._ready and time.monotonic() - self._last_feedback < FEEDBACK_STALE_S

    def wait_connected(self, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.connected:
                return True
            time.sleep(0.01)
        return False

    def set_pressure(self, channel: int, pressure: float) -> None:
        frame = encode_frame(channel, pressure)
        if not self.connected:
            raise PumpError("Pump is not connected.")
        self._write(frame)
        self._commanded[channel] = max(0, min(MAX_PRESSURE_MBAR, int(pressure)))

    def set_pressures(self, pressures: list) -> None:
        """Set every channel in one serial write, so they change together."""
        if len(pressures) != len(PUMP_CHANNELS):
            raise ValueError(f"Expected {len(PUMP_CHANNELS)} pressures.")
        frames = b"".join(encode_frame(c, p) for c, p in zip(PUMP_CHANNELS, pressures))
        if not self.connected:
            raise PumpError("Pump is not connected.")
        self._write(frames)
        self._commanded = [max(0, min(MAX_PRESSURE_MBAR, int(p))) for p in pressures]

    def zero_all(self) -> bool:
        """Command 0 mbar on every channel, even if feedback has gone quiet."""
        try:
            self._write(b"".join(encode_frame(channel, 0) for channel in PUMP_CHANNELS))
            self._commanded = [0] * len(PUMP_CHANNELS)
            return True
        except (PumpError, OSError) as exc:
            self._log.error(f"Could not command 0 mbar: {exc}")
            return False

    def snapshot(self) -> dict:
        return {
            "connected": self.connected,
            "measured": list(self._measured),
            "commanded": list(self._commanded),
            "error": self._error,
        }

    def _write(self, frame: bytes) -> None:
        with self._lock:
            if self._ser is None:
                raise PumpError("Pump port is not open.")
            try:
                self._ser.write(frame)
            except Exception as exc:
                raise PumpError(f"Serial write failed: {exc}") from exc

    def _run(self) -> None:
        while not self._closing.is_set():
            try:
                self._connect()
                self._read_until_lost()
            except Exception as exc:
                self._report(str(exc))
            self._drop_port()
            self._closing.wait(RECONNECT_DELAY_S)

    def _connect(self) -> None:
        ser = self._opener()
        with self._lock:
            self._ser = ser
        self._commanded = [0] * len(PUMP_CHANNELS)  # Opening reset the Arduino

        # Only a line in the pump's feedback format proves this is the pump.
        deadline = time.monotonic() + HANDSHAKE_TIMEOUT_S
        buffer = b""
        while not self._closing.is_set():
            buffer, values = self._read_lines(ser, buffer)
            if values:
                self._ready = True
                self._error = None
                self._last_logged_error = None
                self._log.info("Pump connected")
                return
            if time.monotonic() > deadline:
                raise PumpError("Port opened, but no pump feedback arrived.")

    def _read_until_lost(self) -> None:
        ser = self._ser
        buffer = b""
        while not self._closing.is_set():
            buffer, _ = self._read_lines(ser, buffer)
            if time.monotonic() - self._last_feedback > FEEDBACK_LOST_S:
                raise PumpError("Pump feedback stopped.")

    def _read_lines(self, ser, buffer: bytes):
        data = ser.read(max(1, ser.in_waiting))
        buffer = (buffer + data)[-4096:]
        *lines, buffer = buffer.split(b"\n")
        newest = None
        for line in lines:
            values = parse_feedback(line)
            if values:
                newest = values
        if newest:
            self._measured = newest
            self._last_feedback = time.monotonic()
        return buffer, newest

    def _drop_port(self) -> None:
        with self._lock:
            ser, self._ser = self._ser, None
            self._ready = False
        if ser is not None:
            try:
                ser.close()
            except Exception:
                pass

    def _report(self, message: str) -> None:
        self._error = message
        if message != self._last_logged_error:  # Retries would otherwise flood the log
            self._log.error(f"Pump: {message}")
            self._last_logged_error = message


def real_serial_opener(requested_port: str) -> Callable[[], object]:
    import serial

    def opener():
        port = find_pump_port(requested_port)
        return serial.serial_for_url(
            port, PUMP_BAUDRATE, timeout=0.1, write_timeout=1, exclusive=True
        )

    return opener
