"""Lets an unmodified sync script drive the pump while the server keeps the port.

The script is given a virtual serial port. Its bytes are decoded here, as the
Arduino sketch would decode them, and sent through PumpController. The server stays
the only program on the real port, which keeps live pressure readings working and
lets a stop cut the script off instantly.
"""

import os
import select
import threading
from typing import Optional

from config import PUMP_CHANNELS
from controllers.pump import PumpError


class PumpBridge:
    def __init__(self, pump, log):
        self._pump = pump
        self._log = log
        self._active = False
        self._high_byte: Optional[int] = None
        self._master: Optional[int] = None
        self._slave: Optional[int] = None
        self._thread: Optional[threading.Thread] = None
        self.path: Optional[str] = None
        self.error: Optional[str] = None
        self.frames = 0

    def open(self, virtual_port: bool = True) -> Optional[str]:
        """Start accepting commands. Returns the virtual port's path, if one was made."""
        self._active = True
        self._high_byte = None
        self.error = None
        self.frames = 0
        if virtual_port:
            import tty

            self._master, self._slave = os.openpty()
            tty.setraw(self._slave)
            self.path = os.ttyname(self._slave)
            self._thread = threading.Thread(target=self._read_port, name="pump-bridge", daemon=True)
            self._thread.start()
        return self.path

    def block(self) -> None:
        """Ignore everything from the script from now on."""
        self._active = False

    def close(self) -> None:
        self._active = False
        if self._thread:
            self._thread.join(timeout=1)
            self._thread = None
        for descriptor in (self._master, self._slave):
            if descriptor is not None:
                os.close(descriptor)
        self._master = self._slave = self.path = None

    def _read_port(self) -> None:
        while self._active:
            ready, _, _ = select.select([self._master], [], [], 0.1)
            if ready:
                try:
                    self.feed(os.read(self._master, 1024))
                except OSError:
                    return

    def feed(self, data: bytes) -> None:
        """Decode bytes with the same rules as loop() in the pump sketch."""
        for byte in data:
            if not self._active:
                return
            if not byte & 0x80:
                self._high_byte = byte
                continue
            if self._high_byte is None:
                continue
            pressure = ((self._high_byte & 0x1F) << 7) | (byte & 0x7F)
            channel = (self._high_byte >> 5) & 0x03
            self._high_byte = None
            if channel in PUMP_CHANNELS:
                self._send(channel, pressure)

    def _send(self, channel: int, pressure: int) -> None:
        try:
            self._pump.set_pressure(channel, pressure)
            self.frames += 1
        except PumpError as exc:
            if self.error is None:
                self.error = str(exc)
                self._log.error(f"Pump command from the sync script failed: {exc}")
