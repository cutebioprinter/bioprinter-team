"""Bioprinter GUI server. Run from this folder: uvicorn main:app --host 0.0.0.0 --port 8000"""

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from config import Settings, load_settings
from routers.api import build_router, install_error_handlers
from services.system import System

FRONTEND_DIST = Path(__file__).resolve().parent.parent / "frontend" / "dist"


def create_app(settings: Settings) -> FastAPI:
    system = System(settings)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        system.start()
        yield
        system.close()

    app = FastAPI(title="Bioprinter GUI", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.system = system
    app.include_router(build_router(system))
    install_error_handlers(app)

    if FRONTEND_DIST.is_dir():
        app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")
    return app


app = create_app(load_settings())
