"""HTTP and WebSocket API. Everything except login requires a session."""

import asyncio
import os
import time
import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field, field_validator

import auth
from config import MAX_PRESSURE_MBAR, PUMP_CHANNELS
from controllers.printer import PrinterError
from controllers.pump import PumpError
from services.calibration import COMPOSITION_TOLERANCE
from services.jobs import MAX_FILE_BYTES, JobExists, JobInvalid, valid_name
from services.operations import OperationBusy
from services.print_runner import PrintBusy

STATE_INTERVAL_S = 0.1
FAILED_LOGIN_DELAY_S = 1.0
DEADBAND_MBAR = 10  # The pump sketch treats anything lower as off


class Login(BaseModel):
    password: str


class Purge(BaseModel):
    channels: List[int] = Field(default=[0], min_length=1, max_length=len(PUMP_CHANNELS))
    duration: Optional[float] = Field(default=None, gt=0, le=3600, allow_inf_nan=False)

    @field_validator("channels")
    @classmethod
    def known_channels(cls, channels):
        if len(set(channels)) != len(channels) or any(c not in PUMP_CHANNELS for c in channels):
            raise ValueError("Choose each channel once, from 0, 1 and 2.")
        return channels


def check_pressures(pressures: List[int]) -> List[int]:
    if len(pressures) != len(PUMP_CHANNELS):
        raise ValueError("Give one pressure for each of the 3 channels.")
    if any(p != 0 and not DEADBAND_MBAR <= p <= MAX_PRESSURE_MBAR for p in pressures):
        raise ValueError(f"Each pressure must be 0, or {DEADBAND_MBAR} to {MAX_PRESSURE_MBAR} mbar.")
    if not any(pressures):
        raise ValueError("At least one channel needs pressure.")
    return pressures


class Calibration(BaseModel):
    duration: float = Field(default=50, gt=0, le=3600, allow_inf_nan=False)
    tests: List[List[int]] = Field(min_length=1, max_length=20)

    @field_validator("tests")
    @classmethod
    def valid_tests(cls, tests):
        return [check_pressures(test) for test in tests]


class StartTest(BaseModel):
    pressures: Optional[List[int]] = None

    @field_validator("pressures")
    @classmethod
    def valid_pressures(cls, pressures):
        return None if pressures is None else check_pressures(pressures)


class CalibrationResult(BaseModel):
    weight_mg: float = Field(ge=0, le=10_000_000, allow_inf_nan=False)
    composition: List[float] = Field(min_length=3, max_length=3)

    @field_validator("composition")
    @classmethod
    def adds_to_one(cls, composition):
        if any(part < 0 or part != part for part in composition):
            raise ValueError("Composition values cannot be negative.")
        if abs(sum(composition) - 1) > COMPOSITION_TOLERANCE:
            raise ValueError("Composition must add up to 1.")
        return composition


class JobName(BaseModel):
    name: str


class Gcode(BaseModel):
    command: str = Field(min_length=1, max_length=500, pattern=r"^[^\r\n]*\S[^\r\n]*$")


def build_router(system) -> APIRouter:
    public = APIRouter(prefix="/api")
    private = APIRouter(prefix="/api", dependencies=[Depends(auth.require_session)])

    @public.post("/login")
    def login(body: Login, response: Response):
        if not auth.password_matches(body.password, system.settings.password):
            system.log.warning("Failed login attempt")
            time.sleep(FAILED_LOGIN_DELAY_S)
            raise HTTPException(status_code=401, detail="Wrong password.")
        response.set_cookie(
            auth.COOKIE_NAME, auth.new_session(),
            max_age=auth.SESSION_S, httponly=True, samesite="strict",
        )
        return {"ok": True}

    @public.post("/logout")
    def logout(response: Response):
        response.delete_cookie(auth.COOKIE_NAME)
        return {"ok": True}

    @public.get("/session")
    def session(request: Request):
        return {
            "authenticated": auth.session_valid(request.cookies.get(auth.COOKIE_NAME)),
            "mode": system.settings.mode,
            "maxPressure": MAX_PRESSURE_MBAR,
            "maxPurgeSeconds": system.settings.max_purge_s,
            "dwcUrl": system.settings.dwc_url,
        }

    @private.get("/state")
    def state():
        return system.snapshot()

    @private.post("/ops/purge")
    def purge(body: Purge):
        system.require_not_printing()
        system.ops.purge(body.channels, body.duration)
        return {"ok": True}

    @private.post("/ops/sweep")
    def sweep():
        system.require_not_printing()
        system.ops.sweep()
        return {"ok": True}

    @private.post("/ops/calibrate")
    def calibrate(body: Calibration):
        system.require_not_printing()
        system.ops.calibrate(body.duration, body.tests)
        return {"ok": True}

    @private.post("/ops/calibrate/start")
    def start_test(body: StartTest):
        system.ops.start_test(body.pressures)
        return {"ok": True}

    @private.post("/ops/calibrate/result")
    def save_result(body: CalibrationResult):
        return system.ops.save_result(body.weight_mg, body.composition)

    @private.post("/ops/calibrate/repeat")
    def repeat_test():
        system.ops.repeat_test()
        return {"ok": True}

    @private.get("/calibration/results")
    def calibration_results():
        return system.results.list()

    @private.get("/calibration/results.csv")
    def calibration_csv():
        return PlainTextResponse(
            system.results.csv_text(), media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="calibration_results.csv"'},
        )

    @private.get("/calibration/model")
    def calibration_model():
        return system.calibration_model()

    @private.get("/jobs")
    def list_jobs():
        return system.jobs.list()

    @private.post("/jobs")
    async def upload_job(request: Request, name: str, overwrite: bool = False):
        valid_name(name)
        system.require_not_printing()
        temporary = os.path.join(system.jobs.folder, f".upload-{uuid.uuid4().hex}")
        try:
            received = 0
            with open(temporary, "wb") as file:
                async for chunk in request.stream():
                    received += len(chunk)
                    if received > MAX_FILE_BYTES:
                        raise HTTPException(413, "That file is too large.")
                    file.write(chunk)
            return await run_in_threadpool(system.jobs.add, temporary, name, overwrite)
        finally:
            if os.path.exists(temporary):
                os.remove(temporary)

    @private.post("/jobs/check")
    def check_job(body: JobName):
        return {"result": system.jobs.check(body.name)}

    @private.delete("/calibration/results/{result_id}")
    def delete_result(result_id: str):
        if not system.results.delete(result_id):
            raise HTTPException(404, "Result not found.")
        system.log.info(f"Calibration result {result_id} deleted")
        return {"ok": True}

    @private.post("/ops/stop")
    def stop():
        return {"pump_zeroed": system.ops.stop()}

    @private.post("/print/start")
    def start_print(body: JobName):
        system.runner.start(body.name)
        return {"ok": True}

    @private.post("/print/stop")
    def stop_print():
        system.runner.stop()
        return {"ok": True}

    @private.post("/printer/gcode")
    def gcode(body: Gcode):
        return {"reply": system.send_gcode(body.command)}

    @private.post("/printer/estop")
    def emergency_stop():
        return system.emergency_stop()

    @private.post("/printer/reset")
    def reset():
        system.reset_duet()
        return {"ok": True}

    root = APIRouter()
    root.include_router(public)
    root.include_router(private)

    @root.websocket("/ws")
    async def live_state(socket: WebSocket):
        if not auth.session_valid(socket.cookies.get(auth.COOKIE_NAME)):
            await socket.close(code=4401)
            return
        await socket.accept()
        last_log = 0
        try:
            while True:
                snapshot = system.snapshot(log_after=last_log)
                if snapshot["log"]:
                    last_log = snapshot["log"][-1]["seq"]
                await socket.send_json(snapshot)
                await asyncio.sleep(STATE_INTERVAL_S)
        except (WebSocketDisconnect, RuntimeError):
            pass

    return root


def install_error_handlers(app) -> None:
    def respond_with(status):
        async def respond(request, exc):
            return JSONResponse(status_code=status, content={"detail": str(exc)})

        return respond

    app.add_exception_handler(OperationBusy, respond_with(409))
    app.add_exception_handler(JobExists, respond_with(409))
    app.add_exception_handler(PrintBusy, respond_with(409))
    app.add_exception_handler(JobInvalid, respond_with(422))
    app.add_exception_handler(PumpError, respond_with(503))
    app.add_exception_handler(PrinterError, respond_with(502))
