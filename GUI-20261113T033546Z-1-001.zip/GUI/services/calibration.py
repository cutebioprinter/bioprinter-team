"""Saved flow calibration results, kept as a CSV file that opens in a spreadsheet.

Flow is a mass flow in mg/s: the weight divided by how long pressure was on.
Each channel's share comes from the composition entered for that test.
"""

import csv
import os
import threading
import time
import uuid

import numpy as np

CHANNELS = (0, 1, 2)
COMPOSITION_TOLERANCE = 0.0101  # Allows 0.33, 0.33, 0.33
ACTIVE_PRESSURE_MBAR = 10  # Below this the pump sketch has the channel off

FIELDS = (
    ["id", "session", "recorded_at"]
    + [f"pressure_ch{c}_mbar" for c in CHANNELS]
    + ["on_time_s", "weight_mg"]
    + [f"composition_ch{c}" for c in CHANNELS]
    + ["flow_total_mg_s"]
    + [f"flow_ch{c}_mg_s" for c in CHANNELS]
)


def flow_rates(weight_mg: float, on_time_s: float, composition: list) -> tuple:
    """Return (total flow, [flow per channel]) in mg/s."""
    if on_time_s <= 0:
        raise ValueError("On time must be positive.")
    total = weight_mg / on_time_s
    share = sum(composition)
    return total, [total * part / share for part in composition]


def fit_model(results: list) -> dict:
    """Fit the linear model used by flowrates_to_pressures in gcode_sync_volume.py.

        Pi = Qi * Ri + (Q0 + Q1 + Q2) * RN

    Pressure is in mbar and flow in uL/s (1 mg = 1 uL at the density of water).
    A channel with no pressure is left out of its test, because the model would
    otherwise claim 0 mbar there while the shared node is pressurized.
    """
    rows, pressures = [], []
    for result in results:
        total = sum(result["flows"])
        for channel in CHANNELS:
            if result["pressures"][channel] > 0:
                row = [0.0] * (len(CHANNELS) + 1)
                row[channel] = result["flows"][channel]
                row[-1] = total
                rows.append(row)
                pressures.append(result["pressures"][channel])

    if not rows:
        return {"ready": False, "reason": "No saved results yet.", "tests": 0}

    design = np.array(rows)
    target = np.array(pressures, dtype=float)
    if np.linalg.matrix_rank(design) < design.shape[1]:
        return {
            "ready": False,
            "tests": len(results),
            "reason": (
                "Needs more tests. Every channel must have flow, and at least one test must run "
                "two or more channels together, or the shared resistance cannot be separated."
            ),
        }

    solution, *_ = np.linalg.lstsq(design, target, rcond=None)
    residual = target - design @ solution
    spread = float(np.sum((target - target.mean()) ** 2))
    return {
        "ready": True,
        "tests": len(results),
        "resistances": [float(value) for value in solution[:-1]],
        "shared_resistance": float(solution[-1]),
        "rms_error_mbar": float(np.sqrt(np.mean(residual**2))),
        "r_squared": 1 - float(np.sum(residual**2)) / spread if spread > 0 else None,
        "physical": bool(np.all(solution >= 0)),
    }


def estimate_flows(pressures: list, model: dict):
    """Estimate flow per channel in uL/s from pressures, using a fitted model.

    Solves Pi = Qi * Ri + (Q0 + Q1 + Q2) * RN for the channels that have pressure.
    A channel the model says would flow backwards is treated as not flowing.
    Returns None when the model cannot be used.
    """
    if not model.get("ready") or not model.get("physical"):
        return None

    resistances = np.array(model["resistances"])
    active = [c for c in CHANNELS if pressures[c] >= ACTIVE_PRESSURE_MBAR]
    flows = [0.0] * len(CHANNELS)

    while active:
        system = np.diag(resistances[active]) + model["shared_resistance"]
        try:
            solved = np.linalg.solve(system, np.array([pressures[c] for c in active], dtype=float))
        except np.linalg.LinAlgError:
            return None
        if np.all(solved >= 0):
            for channel, flow in zip(active, solved):
                flows[channel] = float(flow)
            break
        active = [channel for channel, flow in zip(active, solved) if flow >= 0]
    return flows


def _to_row(result: dict) -> dict:
    row = {key: result[key] for key in ("id", "session", "recorded_at", "weight_mg")}
    row["on_time_s"] = f"{result['on_time_s']:.3f}"
    row["flow_total_mg_s"] = f"{result['flow_total']:.4f}"
    for channel in CHANNELS:
        row[f"pressure_ch{channel}_mbar"] = result["pressures"][channel]
        row[f"composition_ch{channel}"] = result["composition"][channel]
        row[f"flow_ch{channel}_mg_s"] = f"{result['flows'][channel]:.4f}"
    return row


def _from_row(row: dict) -> dict:
    return {
        "id": row["id"],
        "session": row["session"],
        "recorded_at": row["recorded_at"],
        "pressures": [int(row[f"pressure_ch{c}_mbar"]) for c in CHANNELS],
        "on_time_s": float(row["on_time_s"]),
        "weight_mg": float(row["weight_mg"]),
        "composition": [float(row[f"composition_ch{c}"]) for c in CHANNELS],
        "flow_total": float(row["flow_total_mg_s"]),
        "flows": [float(row[f"flow_ch{c}_mg_s"]) for c in CHANNELS],
    }


class CalibrationStore:
    def __init__(self, path: str):
        self.path = path
        self.version = 0  # Changes whenever the saved results change
        self._lock = threading.Lock()
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    def add(self, session: str, pressures: list, on_time_s: float, weight_mg: float, composition: list) -> dict:
        total, flows = flow_rates(weight_mg, on_time_s, composition)
        result = {
            "id": uuid.uuid4().hex[:12],
            "session": session,
            "recorded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "pressures": list(pressures),
            "on_time_s": on_time_s,
            "weight_mg": weight_mg,
            "composition": list(composition),
            "flow_total": total,
            "flows": flows,
        }
        with self._lock:
            is_new = not os.path.exists(self.path)
            with open(self.path, "a", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, FIELDS)
                if is_new:
                    writer.writeheader()
                writer.writerow(_to_row(result))
                file.flush()
                os.fsync(file.fileno())  # Survive the Pi losing power
            self.version += 1
        return result

    def _rows(self) -> list:
        if not os.path.exists(self.path):
            return []
        with open(self.path, newline="", encoding="utf-8") as file:
            return list(csv.DictReader(file))

    def list(self) -> list:
        with self._lock:
            return [_from_row(row) for row in self._rows()]

    def delete(self, result_id: str) -> bool:
        with self._lock:
            rows = self._rows()
            kept = [row for row in rows if row["id"] != result_id]
            if len(kept) == len(rows):
                return False
            temporary = f"{self.path}.tmp"
            with open(temporary, "w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, FIELDS)
                writer.writeheader()
                writer.writerows(kept)
                file.flush()
                os.fsync(file.fileno())
            os.replace(temporary, self.path)
            self.version += 1
            return True

    def csv_text(self) -> str:
        with self._lock:
            if not os.path.exists(self.path):
                return ",".join(FIELDS) + "\n"
            with open(self.path, newline="", encoding="utf-8") as file:
                return file.read()
