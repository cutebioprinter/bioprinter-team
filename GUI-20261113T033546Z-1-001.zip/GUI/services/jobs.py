"""G-code files kept identical on the Pi and the Duet.

The sync scripts need the same G-code the Duet is printing, so a file only counts
as uploaded once the Duet has accepted it and its CRC32. If the Duet refuses it,
the Pi's copy is left as it was, and the two never drift apart through this page.
"""

import json
import os
import re
import threading
import time
import zlib

from controllers.printer import PrinterError  # noqa: F401  Raised through add() and check()

MAX_FILE_BYTES = 100_000_000
NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._ -]{0,120}\.(gcode|gc|g|nc)$", re.IGNORECASE)


class JobInvalid(Exception):
    pass


class JobExists(Exception):
    pass


def valid_name(name: str) -> str:
    if not NAME_PATTERN.match(name):
        raise JobInvalid(
            "Use a .gcode file name with only letters, numbers, spaces, dots, dashes and underscores."
        )
    return name


class JobStore:
    def __init__(self, folder: str, duet, log):
        self.folder = folder
        self.version = 0  # Changes whenever the files change
        self._duet = duet
        self._log = log
        self._lock = threading.Lock()
        self._index_path = os.path.join(folder, "index.json")
        os.makedirs(folder, exist_ok=True)
        self._index = self._load_index()

    def _load_index(self) -> dict:
        if not os.path.exists(self._index_path):
            return {}
        with open(self._index_path, encoding="utf-8") as file:
            return json.load(file)

    def _save_index(self) -> None:
        temporary = f"{self._index_path}.tmp"
        with open(temporary, "w", encoding="utf-8") as file:
            json.dump(self._index, file, indent=1)
        os.replace(temporary, self._index_path)

    def add(self, temporary_path: str, name: str, overwrite: bool = False) -> dict:
        """Send a received file to the Duet, then keep it on the Pi."""
        valid_name(name)
        with open(temporary_path, "rb") as file:
            data = file.read()
        if not data:
            raise JobInvalid("The file is empty.")

        with self._lock:
            on_duet = self._duet.list_files()
            if not overwrite and (name in self._index or name in on_duet):
                raise JobExists(f"{name} already exists.")

            crc32 = zlib.crc32(data)
            self._duet.upload_file(name, data, crc32)
            os.replace(temporary_path, os.path.join(self.folder, name))
            record = {
                "size": len(data),
                "crc32": f"{crc32:08x}",
                "uploaded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
            self._index[name] = record
            self._save_index()
            self.version += 1
        self._log.info(f"G-code {name} sent to the Duet and saved on the Pi (CRC32 {record['crc32']})")
        return {"name": name, **record}

    def list(self) -> dict:
        """Every known file, with a quick comparison by size."""
        try:
            on_duet = self._duet.list_files()
            duet_error = None
        except PrinterError as exc:
            on_duet = None
            duet_error = str(exc)

        with self._lock:
            index = dict(self._index)

        files = []
        for name, record in sorted(index.items()):
            if on_duet is None:
                state = "unknown"
            elif name not in on_duet:
                state = "missing_on_duet"
            elif on_duet[name] != record["size"]:
                state = "different"
            else:
                state = "same_size"
            files.append({"name": name, **record, "state": state})
        for name, size in sorted((on_duet or {}).items()):
            if name not in index:
                files.append({"name": name, "size": size, "crc32": None, "uploaded_at": None, "state": "only_on_duet"})
        return {"files": files, "duet_error": duet_error}

    def path_of(self, name: str) -> str:
        with self._lock:
            if name not in self._index:
                raise JobInvalid(f"{name} is not on the Pi.")
        return os.path.join(self.folder, name)

    def check(self, name: str) -> str:
        """Compare the Duet's copy with the Pi's, byte for byte."""
        with self._lock:
            record = self._index.get(name)
        if record is None:
            raise JobInvalid(f"{name} is not on the Pi.")

        data = self._duet.download_file(name)
        if data is None:
            result = "missing_on_duet"
        elif f"{zlib.crc32(data):08x}" == record["crc32"]:
            result = "match"
        else:
            result = "different"
        log = self._log.info if result == "match" else self._log.warning
        log(f"G-code check for {name}: {result}")
        return result
