"""Operation log: a rotating file on disk, and recent entries for the GUI."""

import logging
import os
import threading
import time
from collections import deque
from logging.handlers import RotatingFileHandler


class Logbook:
    def __init__(self, log_dir: str, keep: int = 500):
        self._entries = deque(maxlen=keep)
        self._seq = 0
        self._lock = threading.Lock()
        os.makedirs(log_dir, exist_ok=True)
        self._file = logging.getLogger(f"bioprinter.{id(self)}")
        self._file.setLevel(logging.INFO)
        self._file.propagate = False
        handler = RotatingFileHandler(
            os.path.join(log_dir, "bioprinter.log"), maxBytes=2_000_000, backupCount=5, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        self._file.addHandler(handler)

    def _add(self, level: str, message: str) -> None:
        self._file.log(getattr(logging, level.upper()), message)
        with self._lock:
            self._seq += 1
            self._entries.append(
                {"seq": self._seq, "time": time.time(), "level": level, "message": message}
            )

    def file_only(self, message: str) -> None:
        """For high-volume output that should not fill the live log."""
        self._file.info(message)

    def info(self, message: str) -> None:
        self._add("info", message)

    def warning(self, message: str) -> None:
        self._add("warning", message)

    def error(self, message: str) -> None:
        self._add("error", message)

    def since(self, seq: int) -> list:
        with self._lock:
            return [entry for entry in self._entries if entry["seq"] > seq]

    def close(self) -> None:
        for handler in list(self._file.handlers):
            handler.close()
            self._file.removeHandler(handler)
