"""Pump debug operations, based on src/monitoring/debugPrinter.py.

Only one operation can run at a time. Each runs in its own thread on the Pi, so a
closed browser or dropped Wi-Fi does not affect its timing, and the pump is always
zeroed when it ends, however it ends.
"""

import threading
import time
from typing import Callable, Optional

from config import MAX_PRESSURE_MBAR, PUMP_CHANNELS
from controllers.pump import PumpError

SWEEP_START_MBAR = 8
SWEEP_STEP_MBAR = 10
SWEEP_INTERVAL_S = 0.01
SWEEP_HOLD_S = 1.0
SWEEP_CHANNEL = 0

CHECK_INTERVAL_S = 0.05
ALL_ZERO = [0] * len(PUMP_CHANNELS)


class OperationBusy(Exception):
    pass


class OperationStopped(Exception):
    pass


class OperationManager:
    def __init__(self, pump, log, max_purge_s: float, results):
        self._pump = pump
        self._log = log
        self._max_purge_s = max_purge_s
        self._results = results
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._replied = threading.Event()
        self._reply = None
        self._session = ""
        self._state = self._idle_state()

    @staticmethod
    def _idle_state() -> dict:
        return {
            "kind": None, "status": "idle", "phase": None, "progress": None,
            "targets": list(ALL_ZERO), "step": None, "total_steps": None, "message": "",
            "pressure_safe": True, "next_pressures": None, "pending": None, "test_key": 0,
        }

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def snapshot(self) -> dict:
        return dict(self._state)

    def _update(self, **fields) -> None:
        self._state = {**self._state, **fields}

    def _start(self, kind: str, work: Callable[[], None]) -> None:
        with self._lock:
            if self.running:
                raise OperationBusy(f"{self._state['kind']} is already running.")
            if not self._pump.connected:
                raise PumpError("Pump is not connected.")
            self._stop.clear()
            self._replied.clear()
            self._state = {**self._idle_state(), "kind": kind, "status": "running"}
            self._thread = threading.Thread(target=self._run, args=(kind, work), name=kind, daemon=True)
            self._thread.start()

    def _run(self, kind: str, work: Callable[[], None]) -> None:
        self._log.info(f"{kind} started")
        status, message = "completed", "Finished."
        try:
            work()
        except OperationStopped:
            status, message = "stopped", "Stopped by user."
        except Exception as exc:
            status, message = "error", str(exc)
        finally:
            safe = self._pump.zero_all()

        if not safe:
            status = "error"
            message = f"{message} Could not command 0 mbar. Pressure may still be applied."
        log = self._log.error if status == "error" else self._log.info
        log(f"{kind} {status}: {message}")
        self._update(
            status=status, message=message, targets=list(ALL_ZERO), pressure_safe=safe,
            phase=None, pending=None, next_pressures=None,
        )

    def stop(self) -> bool:
        """Stop whatever is running and command 0 mbar straight away."""
        self._stop.set()
        self._log.info("Stop requested")
        safe = self._pump.zero_all()
        if self.running:
            self._thread.join(timeout=2)
        return safe

    def shutdown(self) -> None:
        if self.running:
            self.stop()

    def _wait(self, seconds: float, on_tick: Optional[Callable[[float], None]] = None) -> None:
        """Sleep, but react to a stop or a lost pump within CHECK_INTERVAL_S."""
        started = time.monotonic()
        end = started + seconds
        while True:
            remaining = end - time.monotonic()
            if remaining <= 0:
                return
            if self._stop.wait(min(remaining, CHECK_INTERVAL_S)):
                raise OperationStopped()
            if not self._pump.connected:
                raise PumpError("Lost connection to the pump.")
            if on_tick:
                on_tick(time.monotonic() - started)

    def purge(self, channels: list, duration: Optional[float] = None) -> None:
        targets = [MAX_PRESSURE_MBAR if c in channels else 0 for c in PUMP_CHANNELS]

        def work():
            limit = duration if duration is not None else self._max_purge_s
            self._pump.set_pressures(targets)
            self._update(targets=targets)

            def tick(elapsed):
                if duration is not None:
                    self._update(progress=elapsed / duration, message=f"{limit - elapsed:.0f} s left")
                else:
                    self._update(message=f"Until stopped ({limit - elapsed:.0f} s safety limit)")

            self._wait(limit, tick)

        self._start("purge", work)

    def sweep(self) -> None:
        levels = list(range(SWEEP_START_MBAR, MAX_PRESSURE_MBAR + 1, SWEEP_STEP_MBAR))

        def work():
            for index, level in enumerate(levels):
                self._pump.set_pressure(SWEEP_CHANNEL, level)
                self._update(targets=[level, 0, 0], progress=(index + 1) / len(levels))
                self._wait(SWEEP_INTERVAL_S)
            self._update(message="Holding at maximum")
            self._wait(SWEEP_HOLD_S)

        self._start("sweep", work)

    # --- Flow calibration ---

    def calibrate(self, duration: float, tests: list) -> None:
        """Run each test, then wait for its weight and composition.

        Pressure is off (0 mbar on all channels) whenever this waits for the user.
        """

        def work():
            self._session = time.strftime("%Y-%m-%d %H:%M:%S")
            plan = list(tests)
            index = 0
            while index < len(plan):
                number, total = index + 1, len(plan)
                pressures = self._await_start(plan[index], number, total)
                plan[index] = pressures  # A repeat keeps any change made at the test
                on_time = self._run_test(pressures, duration, number, total)
                if self._await_result(pressures, on_time, number, total):
                    index += 1

        self._start("calibration", work)

    def _await_start(self, planned: list, number: int, total: int) -> list:
        self._replied.clear()
        self._update(
            status="waiting", phase="ready", step=number, total_steps=total,
            targets=list(ALL_ZERO), progress=None, next_pressures=list(planned), pending=None,
            test_key=self._state["test_key"] + 1,
            message=f"Ready for test {number} of {total}",
        )
        return self._wait_for_reply()

    def _run_test(self, pressures: list, duration: float, number: int, total: int) -> float:
        """Apply pressure for the test duration. Returns the measured on time."""
        self._log.info(f"Calibration test {number}/{total}: {pressures} mbar for {duration} s")
        self._update(status="running", phase="testing", targets=list(pressures), progress=0, next_pressures=None)
        started = time.monotonic()
        self._pump.set_pressures(pressures)

        def tick(elapsed):
            self._update(
                progress=elapsed / duration,
                message=f"Test {number} of {total}: {duration - elapsed:.0f} s left",
            )

        self._wait(duration - (time.monotonic() - started), tick)
        self._pump.set_pressures(ALL_ZERO)
        return time.monotonic() - started

    def _await_result(self, pressures: list, on_time: float, number: int, total: int) -> bool:
        self._replied.clear()
        self._update(
            status="waiting", phase="weigh", targets=list(ALL_ZERO), progress=None,
            pending={"pressures": list(pressures), "on_time_s": on_time},
            test_key=self._state["test_key"] + 1,
            message=f"Test {number} of {total} finished. Weigh the sample.",
        )
        return self._wait_for_reply()

    def _wait_for_reply(self):
        while not self._replied.wait(CHECK_INTERVAL_S):
            if self._stop.is_set():
                raise OperationStopped()
        self._replied.clear()
        return self._reply

    def _send_reply(self, value) -> None:
        self._update(phase="busy")
        self._reply = value
        self._replied.set()

    def _require_phase(self, phase: str, description: str) -> None:
        if not self.running or self._state["phase"] != phase:
            raise OperationBusy(f"Calibration is not {description}.")

    def start_test(self, pressures: Optional[list] = None) -> None:
        """Start the waiting test, optionally with pressures changed by the user."""
        with self._lock:
            self._require_phase("ready", "ready to start a test")
            if not self._pump.connected:
                raise PumpError("Pump is not connected.")
            self._send_reply(pressures or self._state["next_pressures"])

    def save_result(self, weight_mg: float, composition: list) -> dict:
        with self._lock:
            self._require_phase("weigh", "waiting for a weight")
            pending = self._state["pending"]
            result = self._results.add(
                self._session, pending["pressures"], pending["on_time_s"], weight_mg, composition
            )
            self._log.info(
                f"Calibration result: {pending['pressures']} mbar, {weight_mg} mg, "
                f"composition {composition}, {result['flow_total']:.3f} mg/s"
            )
            self._send_reply(True)
            return result

    def repeat_test(self) -> None:
        """Throw away the finished test's result and run that test again."""
        with self._lock:
            self._require_phase("weigh", "waiting for a weight")
            self._log.info("Calibration test discarded, repeating")
            self._send_reply(False)
