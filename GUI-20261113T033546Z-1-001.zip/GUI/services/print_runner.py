"""Quick Start: check a file, start the sync script, start the print, clean up after.

The script is started first and the print only starts once it is listening, so it
cannot miss the first sync markers. Pressure is set to zero however the print ends,
because stopping a process does not stop the pump.
"""

import os
import re
import subprocess
import sys
import threading
import time
from typing import Optional

from controllers.printer import PrinterError
from controllers.pump import PumpError, find_duet_usb_port
from services.jobs import JobInvalid

READY_TEXT = "Connected."
READY_TIMEOUT_S = 30.0
PRINT_START_TIMEOUT_S = 15.0
PAUSE_TIMEOUT_S = 15.0
WATCH_INTERVAL_S = 0.2
TERMINATE_TIMEOUT_S = 3.0
ENDED_POLLS = 3  # The Duet must read "not printing" this many times in a row

PRINTING = {"processing", "paused", "pausing", "resuming", "busy", "simulating"}
ACTIVE = {"checking", "starting_script", "starting_print", "printing", "stopping"}

SYNC_LINE = re.compile(
    r"\[Sync #(?P<sync>\d+).*?current=\((?P<current>[^)]*)\).*?future=\((?P<future>[^)]*)\)"
    r".*?pressures=\((?P<pressures>[^)]*)\)"
)


class PrintBusy(Exception):
    pass


def numbers(text: str) -> list:
    return [float(part) for part in text.split(",")]


class PrintRunner:
    def __init__(self, settings, jobs, duet, pump, bridge, ops, log, duet_status):
        self._settings = settings
        self._jobs = jobs
        self._duet = duet
        self._pump = pump
        self._bridge = bridge
        self._ops = ops
        self._log = log
        self._duet_status = duet_status  # Function returning the latest Duet status
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._emergency = threading.Event()
        self._process: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._ready = threading.Event()
        self._state = self._idle()

    @staticmethod
    def _idle() -> dict:
        return {
            "state": "idle", "file": None, "script": None, "message": "", "predicted": None,
            "commands_sent": 0,
        }

    @property
    def active(self) -> bool:
        return self._state["state"] in ACTIVE

    def snapshot(self) -> dict:
        return {**self._state, "commands_sent": self._bridge.frames}

    def _update(self, **fields) -> None:
        self._state = {**self._state, **fields}

    def script_path(self) -> str:
        if self._settings.sync_script:
            return self._settings.sync_script
        if self._settings.mode == "sim":
            return os.path.join(os.path.dirname(__file__), "..", "simulation", "sync_script.py")
        raise PrintBusy("Set SYNC_SCRIPT to the sync script this printer should run.")

    def start(self, name: str) -> None:
        with self._lock:
            if self.active:
                raise PrintBusy("A Quick Start is already running.")
            script = self.script_path()
            if not os.path.exists(script):
                raise PrintBusy(f"Sync script not found: {script}")
            if self._ops.running:
                raise PrintBusy("A pump operation is running.")
            if not self._pump.connected:
                raise PumpError("Pump is not connected.")
            status = self._duet_status()
            if not status["connected"]:
                raise PrinterError("The Duet is not connected.")
            if status["status"] != "idle":
                raise PrintBusy(f"The Duet is {status['status']}, not idle.")
            self._jobs.path_of(name)

            self._stop.clear()
            self._emergency.clear()
            self._ready.clear()
            self._state = {
                **self._idle(), "state": "checking", "file": name,
                "script": os.path.basename(script), "message": "Checking the Duet's copy matches",
            }
            self._log.info(f"Quick Start: {name}")
            self._thread = threading.Thread(target=self._run, args=(name, script), name="print", daemon=True)
            self._thread.start()

    def _run(self, name: str, script: str) -> None:
        state, message = "finished", "Print finished."
        try:
            self._check_file(name)
            self._start_script(name, script)
            self._start_print(name)
            self._watch_print()
        except _Stopped:
            state, message = "stopped", "Print stopped."
        except _Emergency:
            state, message = "stopped", "Emergency stop."
        except Exception as exc:
            state, message = "failed", str(exc)
            self._pause_after_failure()
        finally:
            self._bridge.block()
            safe = self._pump.zero_all()
            self._end_script()
            self._bridge.close()

        if not safe:
            state = "failed"
            message = f"{message} Could not command 0 mbar. Pressure may still be applied."
        log = self._log.error if state == "failed" else self._log.info
        log(f"Quick Start {state}: {message}")
        self._update(state=state, message=message)

    def _check_stop(self) -> None:
        if self._emergency.is_set():
            raise _Emergency()
        if self._stop.is_set():
            self._cancel_print()
            raise _Stopped()

    def _check_file(self, name: str) -> None:
        if self._jobs.check(name) != "match":
            raise PrintBusy("The Duet's copy does not match the Pi's. Upload the file again.")

    def _start_script(self, name: str, script: str) -> None:
        self._update(state="starting_script", message="Starting the sync script")
        simulated = self._settings.mode == "sim"
        port = self._bridge.open(virtual_port=not simulated)
        command = [sys.executable, "-u", script, "--gcode", self._jobs.path_of(name)]
        if not simulated:
            command += ["--printer-port", self._printer_port(), "--pump-port", port, "--pump-bps", "115200"]
            if self._settings.sync_flow_rate:
                command += ["--flow-rate", str(self._settings.sync_flow_rate)]

        self._process = subprocess.Popen(
            command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
            cwd=os.path.dirname(os.path.abspath(script)),
        )
        threading.Thread(target=self._read_output, args=(self._process,), name="script-output", daemon=True).start()

        deadline = time.monotonic() + READY_TIMEOUT_S
        while not self._ready.wait(WATCH_INTERVAL_S):
            self._check_stop()
            if self._process.poll() is not None:
                raise PrintBusy(f"The sync script exited early (code {self._process.returncode}). See the log.")
            if time.monotonic() > deadline:
                raise PrintBusy("The sync script did not report that it was ready.")

    def _printer_port(self) -> str:
        return find_duet_usb_port(self._settings.duet_usb_port)

    def _read_output(self, process: subprocess.Popen) -> None:
        for line in process.stdout:
            line = line.rstrip()
            if line.startswith("@frame "):  # Simulated script only
                self._bridge.feed(bytes.fromhex(line[7:]))
                continue
            match = SYNC_LINE.search(line)
            if match:
                self._update(predicted={
                    "sync": int(match["sync"]), "current": numbers(match["current"]),
                    "future": numbers(match["future"]), "pressures": numbers(match["pressures"]),
                })
            self._log.file_only(f"sync script: {line}")
            if READY_TEXT in line:
                self._ready.set()

    def _start_print(self, name: str) -> None:
        self._update(state="starting_print", message="Starting the print")
        self._duet.send_gcode(f'M32 "{name}"')
        deadline = time.monotonic() + PRINT_START_TIMEOUT_S
        while self._duet_status()["status"] not in PRINTING:
            self._check_stop()
            if time.monotonic() > deadline:
                raise PrintBusy("The Duet did not start the print.")
            time.sleep(WATCH_INTERVAL_S)

    def _watch_print(self) -> None:
        self._update(state="printing", message="Printing")
        not_printing = 0
        while True:
            self._check_stop()
            if self._bridge.error:
                raise PrintBusy(f"Lost control of the pump: {self._bridge.error}")
            if self._process.poll() is not None:
                raise PrintBusy(f"The sync script stopped during the print (code {self._process.returncode}).")
            status = self._duet_status()
            if not status["connected"]:
                not_printing = 0
            elif status["status"] in PRINTING:
                not_printing = 0
            else:
                not_printing += 1
                if not_printing >= ENDED_POLLS:
                    return
            time.sleep(WATCH_INTERVAL_S * 5)

    def _cancel_print(self) -> None:
        """Pressure first, then pause, then cancel, as the print must not run dry for long."""
        self._update(state="stopping", message="Stopping the print")
        self._bridge.block()
        self._pump.zero_all()
        if self._duet_status()["status"] not in PRINTING:
            return
        self._duet.send_gcode("M25")
        deadline = time.monotonic() + PAUSE_TIMEOUT_S
        while time.monotonic() < deadline:
            if self._duet_status()["status"] == "paused":
                self._duet.send_gcode("M0")
                return
            time.sleep(WATCH_INTERVAL_S)
        raise PrintBusy("The Duet did not pause. Check the printer.")

    def _pause_after_failure(self) -> None:
        """A print with no pressure control should not keep moving."""
        self._bridge.block()
        self._pump.zero_all()
        if self._duet_status()["status"] == "processing":
            try:
                self._duet.send_gcode("M25")
                self._log.warning("Print paused because Quick Start failed")
            except PrinterError as exc:
                self._log.error(f"Could not pause the print: {exc}")

    def _end_script(self) -> None:
        process, self._process = self._process, None
        if process is None or process.poll() is not None:
            return
        process.terminate()
        try:
            process.wait(TERMINATE_TIMEOUT_S)
        except subprocess.TimeoutExpired:
            process.kill()

    def stop(self) -> None:
        if not self.active:
            raise PrintBusy("No Quick Start is running.")
        self._stop.set()

    def emergency(self) -> None:
        """Cut the script off now, so nothing can follow the zero pressure command."""
        if self.active:
            self._emergency.set()
            self._bridge.block()

    def shutdown(self) -> None:
        if self.active:
            self.emergency()
            if self._thread:
                self._thread.join(timeout=TERMINATE_TIMEOUT_S + 2)


class _Stopped(Exception):
    pass


class _Emergency(Exception):
    pass


__all__ = ["PrintRunner", "PrintBusy", "JobInvalid"]
