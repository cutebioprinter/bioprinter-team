"""Builds the hardware layer for the chosen mode and answers "what is happening now"."""

import os
import threading
import time
from collections import deque
from typing import Optional

from config import Settings
from controllers.printer import EMPTY_STATUS, DuetClient, PrinterError
from controllers.pump import PumpController, real_serial_opener
from controllers.pump_bridge import PumpBridge
from services.calibration import CalibrationStore, estimate_flows, fit_model
from services.jobs import JobStore
from services.logbook import Logbook
from services.operations import OperationBusy, OperationManager
from services.print_runner import PrintRunner
from simulation.duet import SimDuet
from simulation.pump import SimSerial

DUET_POLL_S = 1.0
PRINTING_STATES = {"processing", "paused", "pausing", "resuming", "busy"}

# Query-only commands, which stay available during a print.
READ_ONLY_GCODE = ("M105", "M114", "M115", "M119", "M122", "M408", "M409")


class System:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.log = Logbook(settings.log_dir)
        self.sim_serial: Optional[SimSerial] = None

        if settings.mode == "sim":
            def opener():
                self.sim_serial = SimSerial()
                return self.sim_serial

            self.duet = SimDuet()
        else:
            opener = real_serial_opener(settings.pump_port)
            self.duet = DuetClient(settings.duet_url, settings.duet_password)

        self.pump = PumpController(opener, self.log)
        # Simulated results stay apart so they can never mix with real measurements.
        results_file = "calibration_results_simulated.csv" if settings.mode == "sim" else "calibration_results.csv"
        self.results = CalibrationStore(os.path.join(settings.data_dir, results_file))
        self.ops = OperationManager(self.pump, self.log, settings.max_purge_s, self.results)
        self.jobs = JobStore(os.path.join(settings.data_dir, "gcode"), self.duet, self.log)
        self.bridge = PumpBridge(self.pump, self.log)
        self.runner = PrintRunner(
            settings, self.jobs, self.duet, self.pump, self.bridge, self.ops, self.log,
            lambda: self._duet_status,
        )
        self._model = None
        self._model_version = None
        self.history = deque(maxlen=100)
        self._duet_status = dict(EMPTY_STATUS)
        self._gcode_lock = threading.Lock()
        self._closing = threading.Event()
        self._poller = threading.Thread(target=self._poll_duet, name="duet-poll", daemon=True)

    def start(self) -> None:
        self.log.info(f"Server started in {self.settings.mode} mode")
        self.pump.start()
        self._poller.start()

    def close(self) -> None:
        self._closing.set()
        self.runner.shutdown()
        self.ops.shutdown()
        self.pump.zero_all()
        self.pump.close()
        self._poller.join(timeout=4)
        self.log.info("Server stopped")
        self.log.close()

    def _poll_duet(self) -> None:
        was_connected = None
        while not self._closing.is_set():
            self._refresh_duet()
            connected = self._duet_status["connected"]
            if connected != was_connected:
                if connected:
                    self.log.info("Duet connected")
                else:
                    self.log.error(f"Duet not reachable: {self._duet_status['error']}")
                was_connected = connected
            self._closing.wait(DUET_POLL_S)

    def _refresh_duet(self) -> None:
        try:
            self._duet_status = self.duet.status()
        except PrinterError as exc:
            self._duet_status = {**EMPTY_STATUS, "error": str(exc)}

    @property
    def printing(self) -> bool:
        return self.runner.active or self._duet_status["status"] in PRINTING_STATES

    def require_not_printing(self) -> None:
        if self.printing:
            raise OperationBusy("A print is running, and print scripts control the pump.")

    def send_gcode(self, command: str) -> str:
        command = command.strip()
        code = command.split()[0].upper()
        if self.printing and code not in READ_ONLY_GCODE:
            raise OperationBusy("A print is running. Only status queries are allowed.")

        self.log.info(f"G-code sent: {command}")
        entry = {"time": time.time(), "command": command, "reply": "", "error": None}
        try:
            with self._gcode_lock:
                entry["reply"] = self.duet.send_gcode(command)
        except PrinterError as exc:
            entry["error"] = str(exc)
            self.log.error(f"G-code failed: {exc}")
            raise
        finally:
            self.history.append(entry)
        self._refresh_duet()
        return entry["reply"]

    def emergency_stop(self) -> dict:
        """Tell both the pump and the Duet to stop; one failing must not block the other."""
        self.log.warning("EMERGENCY STOP requested")
        self.runner.emergency()  # First, so the script cannot follow the zero command
        pump_safe = self.ops.stop()
        duet_error = None
        try:
            self.duet.emergency_stop()
        except PrinterError as exc:
            duet_error = str(exc)
            self.log.error(f"Emergency stop did not reach the Duet: {exc}")
        self._refresh_duet()
        return {"pump_zeroed": pump_safe, "duet_error": duet_error}

    def reset_duet(self) -> None:
        self.log.info("Duet reset requested")
        self.duet.reset()
        self._refresh_duet()

    def calibration_model(self) -> dict:
        """The fitted model, recalculated only when the saved results change."""
        if self._model_version != self.results.version or self._model is None:
            self._model_version = self.results.version
            self._model = fit_model(self.results.list())
        return self._model

    def flow_estimate(self, measured: list) -> dict:
        model = self.calibration_model()
        flows = estimate_flows(measured, model)
        if flows is None:
            reason = model.get("reason") or "The fitted model is not physically meaningful yet."
            return {"flows": None, "total": None, "reason": reason}
        return {"flows": flows, "total": sum(flows), "reason": None}

    def snapshot(self, log_after: int = 0) -> dict:
        pump = self.pump.snapshot()
        return {
            "mode": self.settings.mode,
            "pump": pump,
            "flow_estimate": self.flow_estimate(pump["measured"]),
            "duet": self._duet_status,
            "operation": self.ops.snapshot(),
            "calibration_version": self.results.version,
            "jobs_version": self.jobs.version,
            "print": self.runner.snapshot(),
            "history": list(self.history),
            "log": self.log.since(log_after),
        }
