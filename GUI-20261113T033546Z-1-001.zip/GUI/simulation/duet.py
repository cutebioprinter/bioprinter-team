"""Stands in for controllers.printer.DuetClient."""

import re
import time
import zlib

from controllers.printer import PrinterError


class SimDuet:
    def __init__(self):
        self.reachable = True
        self.state = "idle"
        self.file = None
        self.position = {"X": 0.0, "Y": 0.0, "Z": 0.0}
        self.files = {}
        self.print_seconds = 20.0
        self._print_ends = 0.0
        self.damage_uploads = False  # For tests: the file changes in transit

    def _check_reachable(self) -> None:
        if not self.reachable:
            raise PrinterError("Cannot reach Duet: simulated disconnect")

    def send_gcode(self, command: str) -> str:
        self._check_reachable()
        if self.state == "halted":
            raise PrinterError("Duet is halted after an emergency stop. Reset it first.")

        code = command.strip().upper()
        if code.startswith(("G0", "G1")):
            for axis, value in re.findall(r"([XYZ])(-?\d+\.?\d*)", code):
                self.position[axis] = float(value)
            return ""
        if code == "G28":
            self.position = {"X": 0.0, "Y": 0.0, "Z": 0.0}
            return ""
        if code.startswith("M114"):
            p = self.position
            return f"X:{p['X']:.3f} Y:{p['Y']:.3f} Z:{p['Z']:.3f} E:0.000"
        if code.startswith("M115"):
            return "FIRMWARE_NAME: RepRapFirmware (simulated) ELECTRONICS: Duet 3 MB6HC"
        if code.startswith("M32"):
            self.state, self.file = "processing", command.split(None, 1)[-1].strip('" ')
            self._print_ends = time.monotonic() + self.print_seconds
            return ""
        if code.startswith("M25"):
            self.state = "paused"
            return ""
        if code.startswith("M24"):
            self.state = "processing"
            return ""
        if code == "M0":
            self.state, self.file = "idle", None
            return ""
        return "ok (simulated)"

    def list_files(self) -> dict:
        self._check_reachable()
        return {name: len(data) for name, data in self.files.items()}

    def upload_file(self, name: str, data: bytes, crc32: int) -> None:
        self._check_reachable()
        received = data + b"x" if self.damage_uploads else data
        if zlib.crc32(received) != crc32:
            raise PrinterError("The Duet rejected the upload, so the file may have been damaged in transit.")
        self.files[name] = received

    def download_file(self, name: str):
        self._check_reachable()
        return self.files.get(name)

    def emergency_stop(self) -> None:
        self._check_reachable()
        self.state = "halted"

    def reset(self) -> None:
        self._check_reachable()
        self.state, self.file = "idle", None

    def status(self) -> dict:
        self._check_reachable()
        if self.state == "processing" and time.monotonic() > self._print_ends:
            self.state, self.file = "idle", None
        return {
            "connected": True,
            "status": self.state,
            "file": self.file,
            "position": dict(self.position),
            "error": None,
        }
