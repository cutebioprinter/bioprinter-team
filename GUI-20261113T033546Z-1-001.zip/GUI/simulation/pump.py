"""Stands in for the pump's serial port.

Applies the same rules as the Arduino sketch to the bytes it receives, so
PumpController and everything above it runs unchanged in simulation.
"""

import random
import time

from serial import SerialException

MAX_PRESSURE_MBAR = 2068
DEADBAND_MBAR = 10
NUM_PUMPS = 3
FEEDBACK_INTERVAL_S = 0.05
RESPONSE_TIME_S = 0.3
BOOT_TIME_S = 0.3


class SimSerial:
    def __init__(self, timeout: float = 0.1):
        self.timeout = timeout
        self.unplugged = False
        self.received = []  # (channel, pressure) in arrival order, for tests
        self._targets = [0.0] * NUM_PUMPS
        self._pressures = [0.0] * NUM_PUMPS
        self._high_byte = None
        self._updated = time.monotonic()
        self._next_feedback = self._updated + BOOT_TIME_S
        self._rx = b""

    def write(self, data: bytes) -> int:
        self._check_plugged_in()
        for byte in data:
            if byte & 0x80:
                if self._high_byte is not None:
                    pressure = ((self._high_byte & 0x1F) << 7) | (byte & 0x7F)
                    channel = (self._high_byte >> 5) & 0x03
                    self._high_byte = None
                    if channel < NUM_PUMPS:
                        self._apply(channel, pressure)
            else:
                self._high_byte = byte
        return len(data)

    def _apply(self, channel: int, pressure: int) -> None:
        pressure = min(pressure, MAX_PRESSURE_MBAR)
        self.received.append((channel, pressure))
        self._settle()
        self._targets[channel] = float(pressure) if pressure >= DEADBAND_MBAR else 0.0

    def _settle(self) -> None:
        now = time.monotonic()
        step = min(1.0, (now - self._updated) / RESPONSE_TIME_S)
        self._updated = now
        for i in range(NUM_PUMPS):
            self._pressures[i] += (self._targets[i] - self._pressures[i]) * step

    def _produce_feedback(self) -> None:
        now = time.monotonic()
        while now >= self._next_feedback:
            self._settle()
            noisy = [max(0.0, p + random.uniform(-1, 1)) for p in self._pressures]
            self._rx += (",".join(f"{p:.1f}" for p in noisy) + "\r\n").encode()
            self._next_feedback += FEEDBACK_INTERVAL_S

    def _check_plugged_in(self) -> None:
        if self.unplugged:
            raise SerialException("device disconnected")

    @property
    def in_waiting(self) -> int:
        self._check_plugged_in()
        self._produce_feedback()
        return len(self._rx)

    def read(self, size: int = 1) -> bytes:
        deadline = time.monotonic() + self.timeout
        while not self.in_waiting and time.monotonic() < deadline:
            time.sleep(0.005)
        data, self._rx = self._rx[:size], self._rx[size:]
        return data

    def close(self) -> None:
        pass
