"""Stands in for gcode_sync_volume.py in simulation.

Prints the same style of output. It has no serial port to write to, so it prints
pump commands as hex and the server feeds them to the pump bridge.
"""

import argparse
import math
import time


def frame(channel: int, pressure: int) -> str:
    high = (channel << 5) | ((pressure >> 7) & 0x1F)
    return bytes([high, 0x80 | (pressure & 0x7F)]).hex()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gcode", required=True)
    parser.parse_args()

    print("Connected. Waiting for explicit @sync messages from the printer.")
    sync = 0
    started = time.monotonic()
    while True:
        t = time.monotonic() - started
        pressures = [int(300 + 200 * math.sin(t / 2 + c)) for c in range(3)]
        for channel, pressure in enumerate(pressures):
            print(f"@frame {frame(channel, pressure)}")
        print(
            f"[Sync #{sync} | clock scale 1.00] t={t:.2f}s | "
            f"current=({50 + t:.2f}, 40.00, 0.20) | volume-lookahead=25.000 | "
            f"future=({60 + t:.2f}, 40.00, 0.20) | ratio=(0.3, 0.3, 0.4) | "
            f"flows=(0.7, 0.7, 1.0) | pressures=({pressures[0]}, {pressures[1]}, {pressures[2]})"
        )
        sync += 1
        time.sleep(0.25)


if __name__ == "__main__":
    main()
