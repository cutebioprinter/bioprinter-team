import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace as NS

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Settings
from controllers.pump import PumpError, encode_frame, find_pump_port, parse_feedback
from main import create_app
from services import operations
from simulation.pump import SimSerial

PASSWORD = "test-password"


def wait_until(check, timeout=5.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if check():
            return True
        time.sleep(0.01)
    return False


@pytest.fixture
def rig(tmp_path):
    app = create_app(Settings(mode="sim", password=PASSWORD, log_dir=str(tmp_path), data_dir=str(tmp_path), max_purge_s=1.0))
    with TestClient(app) as client:
        system = app.state.system
        assert system.pump.wait_connected(3)
        assert client.post("/api/login", json={"password": PASSWORD}).status_code == 200
        yield NS(client=client, system=system, sim=lambda: system.sim_serial)


def settled(rig):
    assert wait_until(lambda: not rig.system.ops.running)
    return rig.system.ops.snapshot()


# --- Protocol ---

def debug_printer_frame(channel, pressure):
    command = 0x80
    command |= (channel << 13) & 0x6000
    command |= (pressure << 1) & 0x1F00
    command |= pressure & 0x007F
    return command.to_bytes(2, "big")


def test_frames_match_debug_printer():
    for channel in range(3):
        for pressure in range(2069):
            assert encode_frame(channel, pressure) == debug_printer_frame(channel, pressure)


def test_every_frame_decodes_as_the_sketch_does():
    sim = SimSerial()
    for channel in range(3):
        for pressure in range(2069):
            sim.write(encode_frame(channel, pressure))
            assert sim.received[-1] == (channel, pressure)


@pytest.mark.parametrize("channel", [3, 4, -1])
def test_rejects_bad_channels(channel):
    with pytest.raises(ValueError):
        encode_frame(channel, 100)


@pytest.mark.parametrize("value", [float("nan"), float("inf")])
def test_rejects_non_finite_pressure(value):
    with pytest.raises(ValueError):
        encode_frame(0, value)


def test_clamps_pressure():
    assert encode_frame(0, 5000) == encode_frame(0, 2068)
    assert encode_frame(0, -1) == encode_frame(0, 0)


def test_feedback_parsing():
    assert parse_feedback(b"12.5,0.0,3.1\r") == [12.5, 0.0, 3.1]
    assert parse_feedback(b"12.5,0.0") is None
    assert parse_feedback(b"ok") is None
    assert parse_feedback(b"nan,1,2") is None


# --- Port selection ---

ARDUINO = NS(device="/dev/ttyACM1", vid=0x2341)
CLONE = NS(device="/dev/ttyUSB0", vid=0x1A86)
DUET = NS(device="/dev/ttyACM0", vid=0x1D50)


def test_auto_finds_arduino_beside_duet():
    assert find_pump_port("auto", [DUET, ARDUINO]) == "/dev/ttyACM1"


@pytest.mark.parametrize("ports", [[DUET], [ARDUINO, CLONE]])
def test_auto_refuses_to_guess(ports):
    with pytest.raises(PumpError):
        find_pump_port("auto", ports)


def test_refuses_duet_port():
    with pytest.raises(PumpError):
        find_pump_port("/dev/ttyACM0", [DUET, ARDUINO])


# --- Operations ---

def test_timed_purge_uses_channel_0_then_zeroes(rig):
    assert rig.client.post("/api/ops/purge", json={"duration": 0.2}).status_code == 200
    state = settled(rig)
    assert state["status"] == "completed"
    received = rig.sim().received
    assert received[0] == (0, 2068)
    assert set(received[-3:]) == {(0, 0), (1, 0), (2, 0)}


def test_open_ended_purge_stops_at_safety_limit(rig):
    rig.client.post("/api/ops/purge", json={})
    assert wait_until(lambda: rig.system.ops.snapshot()["status"] == "completed", 3)
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_stop_ends_purge_and_zeroes(rig):
    rig.client.post("/api/ops/purge", json={"duration": 30})
    assert rig.client.post("/api/ops/stop").json() == {"pump_zeroed": True}
    assert settled(rig)["status"] == "stopped"
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_sweep_matches_debug_printer(rig, monkeypatch):
    monkeypatch.setattr(operations, "SWEEP_HOLD_S", 0.01)
    rig.client.post("/api/ops/sweep")
    time.sleep(0.05)
    assert wait_until(lambda: not rig.system.ops.running, 15)
    levels = [pressure for channel, pressure in rig.sim().received if channel == 0]
    assert levels[:207] == list(range(8, 2069, 10))
    assert levels[-1] == 0


def wait_phase(rig, phase, step=None):
    ops = rig.system.ops
    ok = wait_until(lambda: ops.snapshot()["phase"] == phase and step in (None, ops.snapshot()["step"]))
    assert ok, ops.snapshot()


COMPOSITION = [0.1, 0.24, 0.66]


def test_purge_only_selected_channels(rig):
    assert rig.client.post("/api/ops/purge", json={"channels": [1, 2], "duration": 0.2}).status_code == 200
    assert wait_until(lambda: len(rig.sim().received) >= 3)
    assert rig.sim().received[:3] == [(0, 0), (1, 2068), (2, 2068)]
    assert settled(rig)["status"] == "completed"
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


@pytest.mark.parametrize("channels", [[], [3], [0, 0], [-1]])
def test_purge_rejects_bad_channels(rig, channels):
    assert rig.client.post("/api/ops/purge", json={"channels": channels}).status_code == 422
    assert not rig.system.ops.running


def test_calibration_sets_all_channels_at_once_and_saves_flows(rig):
    body = {"duration": 0.4, "tests": [[200, 100, 50]]}
    assert rig.client.post("/api/ops/calibrate", json=body).status_code == 200
    wait_phase(rig, "ready", 1)
    assert rig.sim().received == []  # Nothing happens until the user starts the test
    assert rig.client.post("/api/ops/calibrate/start", json={}).status_code == 200
    wait_phase(rig, "weigh", 1)

    assert rig.sim().received[:6] == [(0, 200), (1, 100), (2, 50), (0, 0), (1, 0), (2, 0)]
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]
    on_time = rig.system.ops.snapshot()["pending"]["on_time_s"]
    assert 0.39 < on_time < 0.5

    response = rig.client.post("/api/ops/calibrate/result", json={"weight_mg": 80, "composition": COMPOSITION})
    assert response.status_code == 200
    assert settled(rig)["status"] == "completed"

    saved = rig.client.get("/api/calibration/results").json()
    assert len(saved) == 1
    assert saved[0]["pressures"] == [200, 100, 50]
    assert saved[0]["composition"] == COMPOSITION
    assert saved[0]["flow_total"] == pytest.approx(80 / on_time, abs=1e-3)
    assert saved[0]["flows"][2] == pytest.approx(0.66 * 80 / on_time, abs=1e-3)


def test_start_can_change_the_planned_pressures(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 0.1, "tests": [[200, 0, 0]]})
    wait_phase(rig, "ready")
    assert rig.client.post("/api/ops/calibrate/start", json={"pressures": [0, 300, 40]}).status_code == 200
    wait_phase(rig, "weigh")
    assert rig.sim().received[:3] == [(0, 0), (1, 300), (2, 40)]
    rig.client.post("/api/ops/stop")


def test_repeat_keeps_pressures_changed_at_the_test(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 0.1, "tests": [[200, 0, 0]]})
    wait_phase(rig, "ready", 1)
    rig.client.post("/api/ops/calibrate/start", json={"pressures": [0, 250, 0]})
    wait_phase(rig, "weigh", 1)
    rig.client.post("/api/ops/calibrate/repeat")
    wait_phase(rig, "ready", 1)
    assert rig.system.ops.snapshot()["next_pressures"] == [0, 250, 0]
    rig.client.post("/api/ops/stop")


def test_calibration_waits_for_the_weight_before_the_next_test(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 0.1, "tests": [[200, 0, 0], [40, 0, 0]]})
    wait_phase(rig, "ready", 1)
    rig.client.post("/api/ops/calibrate/start", json={})
    wait_phase(rig, "weigh", 1)
    assert rig.client.post("/api/ops/calibrate/start", json={}).status_code == 409
    time.sleep(0.1)
    assert (0, 40) not in rig.sim().received
    rig.client.post("/api/ops/calibrate/result", json={"weight_mg": 5, "composition": [1, 0, 0]})
    wait_phase(rig, "ready", 2)
    rig.client.post("/api/ops/calibrate/start", json={})
    wait_phase(rig, "weigh", 2)
    assert (0, 40) in rig.sim().received
    rig.client.post("/api/ops/calibrate/result", json={"weight_mg": 2, "composition": [1, 0, 0]})
    assert settled(rig)["status"] == "completed"
    assert len(rig.client.get("/api/calibration/results").json()) == 2


def test_repeat_saves_nothing_and_runs_the_same_test(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 0.1, "tests": [[200, 0, 0]]})
    wait_phase(rig, "ready", 1)
    rig.client.post("/api/ops/calibrate/start", json={})
    wait_phase(rig, "weigh", 1)
    assert rig.client.post("/api/ops/calibrate/repeat").status_code == 200
    wait_phase(rig, "ready", 1)
    assert rig.client.get("/api/calibration/results").json() == []
    rig.client.post("/api/ops/stop")


def test_stopped_test_saves_nothing_and_zeroes(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 30, "tests": [[200, 100, 50]]})
    wait_phase(rig, "ready")
    rig.client.post("/api/ops/calibrate/start", json={})
    wait_phase(rig, "testing")
    rig.client.post("/api/ops/stop")
    assert settled(rig)["status"] == "stopped"
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]
    assert rig.client.get("/api/calibration/results").json() == []


def test_stop_while_calibration_waits(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 5, "tests": [[100, 0, 0]]})
    wait_phase(rig, "ready")
    rig.client.post("/api/ops/stop")
    assert settled(rig)["status"] == "stopped"


def test_results_survive_a_restart_and_can_be_deleted(tmp_path):
    from services.calibration import CalibrationStore

    path = str(tmp_path / "results.csv")
    first = CalibrationStore(path).add("s", [200, 0, 0], 50.0, 100.0, [1.0, 0.0, 0.0])
    second = CalibrationStore(path)
    assert second.list() == [first]
    assert first["flow_total"] == 2.0 and first["flows"] == [2.0, 0.0, 0.0]
    assert "flow_ch0_mg_s" in second.csv_text()
    assert second.delete(first["id"]) is True
    assert second.delete(first["id"]) is False
    assert second.list() == []


def test_results_csv_download(rig):
    response = rig.client.get("/api/calibration/results.csv")
    assert response.status_code == 200 and "weight_mg" in response.text
    assert rig.client.delete("/api/calibration/results/missing").status_code == 404


def test_second_operation_is_refused(rig):
    rig.client.post("/api/ops/purge", json={"duration": 30})
    assert rig.client.post("/api/ops/sweep").status_code == 409
    rig.client.post("/api/ops/stop")


def test_unplugged_pump_ends_operation_with_error(rig):
    rig.client.post("/api/ops/purge", json={"duration": 30})
    rig.sim().unplugged = True
    state = settled(rig)
    assert state["status"] == "error"
    assert state["pressure_safe"] is False
    assert "Pressure may still be applied" in state["message"]


def test_pump_reconnects_after_unplug(rig, monkeypatch):
    import controllers.pump as pump_module

    monkeypatch.setattr(pump_module, "RECONNECT_DELAY_S", 0.05)
    first = rig.sim()
    first.unplugged = True
    assert wait_until(lambda: not rig.system.pump.connected)
    assert wait_until(lambda: rig.system.pump.connected and rig.sim() is not first, 5)


def test_shutdown_zeroes_a_running_operation(tmp_path):
    app = create_app(Settings(mode="sim", password=PASSWORD, log_dir=str(tmp_path), data_dir=str(tmp_path)))
    with TestClient(app) as client:
        system = app.state.system
        assert system.pump.wait_connected(3)
        client.post("/api/login", json={"password": PASSWORD})
        client.post("/api/ops/purge", json={"duration": 30})
        sim = system.sim_serial
    assert set(sim.received[-3:]) == {(0, 0), (1, 0), (2, 0)}


@pytest.mark.parametrize("body", [
    {"duration": 0, "tests": [[100, 0, 0]]},
    {"duration": 10, "tests": []},
    {"duration": 10, "tests": [[0, 0, 0]]},
    {"duration": 10, "tests": [[2069, 0, 0]]},
    {"duration": 10, "tests": [[-5, 100, 0]]},
    {"duration": 10, "tests": [[5, 100, 0]]},
    {"duration": 10, "tests": [[100, 0]]},
])
def test_calibration_validation(rig, body):
    assert rig.client.post("/api/ops/calibrate", json=body).status_code == 422


@pytest.mark.parametrize("body", [
    {"weight_mg": -1, "composition": [1, 0, 0]},
    {"weight_mg": 5, "composition": [0.5, 0.2, 0.1]},
    {"weight_mg": 5, "composition": [1.5, -0.5, 0]},
    {"weight_mg": 5, "composition": [1, 0]},
])
def test_result_validation(rig, body):
    rig.client.post("/api/ops/calibrate", json={"duration": 0.1, "tests": [[100, 0, 0]]})
    wait_phase(rig, "ready")
    rig.client.post("/api/ops/calibrate/start", json={})
    wait_phase(rig, "weigh")
    assert rig.client.post("/api/ops/calibrate/result", json=body).status_code == 422
    assert rig.system.ops.snapshot()["phase"] == "weigh"
    rig.client.post("/api/ops/stop")


def test_rounded_thirds_are_accepted(rig):
    rig.client.post("/api/ops/calibrate", json={"duration": 0.1, "tests": [[100, 0, 0]]})
    wait_phase(rig, "ready")
    rig.client.post("/api/ops/calibrate/start", json={})
    wait_phase(rig, "weigh")
    body = {"weight_mg": 5, "composition": [0.33, 0.33, 0.33]}
    assert rig.client.post("/api/ops/calibrate/result", json=body).status_code == 200


def result(pressures, flows):
    return {"pressures": pressures, "flows": flows}


def test_model_recovers_known_resistances():
    from services.calibration import fit_model

    r, rn = [40.0, 10.0, 25.0], 10.0
    flows = [[5, 0, 0], [0, 8, 0], [0, 0, 4], [3, 6, 2], [6, 2, 5], [1, 7, 7]]
    results = []
    for q in flows:
        total = sum(q)
        results.append(result([(q[c] * r[c] + total * rn) if q[c] else 0 for c in range(3)], q))
    model = fit_model(results)
    assert model["ready"] is True and model["physical"] is True
    assert model["resistances"] == pytest.approx(r)
    assert model["shared_resistance"] == pytest.approx(rn)
    assert model["rms_error_mbar"] == pytest.approx(0, abs=1e-6)


def test_model_needs_a_test_with_channels_together():
    from services.calibration import fit_model

    single = [result([100, 0, 0], [2, 0, 0]), result([0, 100, 0], [0, 2, 0]), result([0, 0, 100], [0, 0, 2])]
    assert fit_model(single)["ready"] is False
    assert fit_model([])["ready"] is False


MODEL = {"ready": True, "physical": True, "resistances": [40.0, 10.0, 25.0], "shared_resistance": 10.0}


def pressures_for(flows):
    total = sum(flows)
    return [q * r + total * 10.0 if q else 0.0 for q, r in zip(flows, MODEL["resistances"])]


@pytest.mark.parametrize("flows", [[5, 0, 0], [0, 8, 0], [3, 6, 2], [6, 0, 5]])
def test_flow_estimate_inverts_the_pressure_model(flows):
    from services.calibration import estimate_flows

    assert estimate_flows(pressures_for(flows), MODEL) == pytest.approx(flows)


def test_flow_estimate_ignores_channels_that_are_off():
    from services.calibration import estimate_flows

    assert estimate_flows([0.0, 9.0, 3.0], MODEL) == [0.0, 0.0, 0.0]


def test_flow_estimate_never_reports_backward_flow():
    from services.calibration import estimate_flows

    flows = estimate_flows([1000.0, 20.0, 0.0], MODEL)  # Channel 1 is below the shared pressure
    assert flows[1] == 0.0 and flows[0] == pytest.approx(1000.0 / 50.0)


def test_flow_estimate_needs_a_usable_model():
    from services.calibration import estimate_flows

    assert estimate_flows([100.0, 0.0, 0.0], {"ready": False}) is None
    assert estimate_flows([100.0, 0.0, 0.0], {**MODEL, "physical": False}) is None


def test_state_reports_flow_after_calibration_is_saved(rig):
    before = rig.system.snapshot()["flow_estimate"]
    assert before["flows"] is None and before["reason"]

    for flows in ([5, 0, 0], [0, 8, 0], [0, 0, 4], [3, 6, 2], [6, 2, 5], [1, 7, 7]):
        total = sum(flows)
        rig.system.results.add(
            "s", [round(p) for p in pressures_for(flows)], 50.0, total * 50.0,
            [q / total for q in flows],
        )
    rig.client.post("/api/ops/purge", json={"channels": [0], "duration": 2})
    assert wait_until(lambda: rig.system.pump.snapshot()["measured"][0] > 1500)
    state = rig.client.get("/api/state").json()["flow_estimate"]
    assert state["reason"] is None and state["flows"][0] > 25 and state["flows"][1] == 0
    rig.client.post("/api/ops/stop")


def test_model_endpoint(rig):
    assert rig.client.get("/api/calibration/model").json()["ready"] is False


# --- G-code files ---

GCODE = b"G1 X10 Y20\nM118 S\"@sync 0\"\n"


def upload(rig, name="job.gcode", data=GCODE, overwrite=False):
    query = {"name": name, "overwrite": str(overwrite).lower()}
    return rig.client.post("/api/jobs", params=query, content=data)


def test_upload_puts_identical_file_on_pi_and_duet(rig):
    assert upload(rig).status_code == 200
    assert rig.system.duet.files["job.gcode"] == GCODE
    with open(Path(rig.system.jobs.folder) / "job.gcode", "rb") as file:
        assert file.read() == GCODE
    assert rig.client.get("/api/jobs").json()["files"][0]["state"] == "same_size"
    assert rig.client.post("/api/jobs/check", json={"name": "job.gcode"}).json() == {"result": "match"}


def test_check_finds_a_file_changed_on_the_duet(rig):
    upload(rig)
    rig.system.duet.files["job.gcode"] = GCODE[:-1] + b"X"  # Same size, different content
    assert rig.client.get("/api/jobs").json()["files"][0]["state"] == "same_size"
    assert rig.client.post("/api/jobs/check", json={"name": "job.gcode"}).json() == {"result": "different"}


def test_check_finds_a_file_missing_from_the_duet(rig):
    upload(rig)
    del rig.system.duet.files["job.gcode"]
    assert rig.client.get("/api/jobs").json()["files"][0]["state"] == "missing_on_duet"
    assert rig.client.post("/api/jobs/check", json={"name": "job.gcode"}).json() == {"result": "missing_on_duet"}


def test_failed_upload_leaves_the_pi_copy_alone(rig):
    upload(rig)
    rig.system.duet.damage_uploads = True
    assert upload(rig, data=b"G1 X99\n", overwrite=True).status_code == 502
    with open(Path(rig.system.jobs.folder) / "job.gcode", "rb") as file:
        assert file.read() == GCODE
    assert not [n for n in os.listdir(rig.system.jobs.folder) if n.startswith(".upload")]


def test_unreachable_duet_saves_nothing(rig):
    rig.system.duet.reachable = False
    assert upload(rig).status_code == 502
    assert rig.client.get("/api/jobs").json()["files"] == []


def test_replacing_needs_overwrite(rig):
    upload(rig)
    assert upload(rig, data=b"G1 X1\n").status_code == 409
    assert rig.system.duet.files["job.gcode"] == GCODE
    assert upload(rig, data=b"G1 X1\n", overwrite=True).status_code == 200
    assert rig.system.duet.files["job.gcode"] == b"G1 X1\n"


def test_file_only_on_duet_is_listed_and_not_overwritten(rig):
    rig.system.duet.files["web.gcode"] = b"G1 X5\n"
    assert rig.client.get("/api/jobs").json()["files"][0]["state"] == "only_on_duet"
    assert upload(rig, name="web.gcode").status_code == 409


@pytest.mark.parametrize("name", ["../evil.gcode", "a/b.gcode", "..\\x.gcode", "job.txt", ".gcode", ""])
def test_unsafe_file_names_are_refused(rig, name):
    assert upload(rig, name=name).status_code == 422
    assert rig.system.duet.files == {}


def test_empty_file_is_refused(rig):
    assert upload(rig, data=b"").status_code == 422


def test_upload_blocked_during_print(rig):
    rig.client.post("/api/printer/gcode", json={"command": 'M32 "job.gcode"'})
    assert upload(rig).status_code == 409
    assert rig.system.duet.files == {}


def test_upload_needs_login(rig):
    rig.client.cookies.clear()
    assert upload(rig).status_code == 401


# --- Quick Start ---

def script_rig(rig, tmp_path, body):
    path = tmp_path / "script.py"
    path.write_text(body)
    rig.system.runner._settings = Settings(mode="sim", sync_script=str(path))


def wait_print(rig, *states):
    runner = rig.system.runner
    assert wait_until(lambda: runner.snapshot()["state"] in states, 15), runner.snapshot()
    return runner.snapshot()


def start_print(rig):
    rig.system.duet.print_seconds = 1.5
    upload(rig)
    time.sleep(1.1)  # The status poll runs once a second
    return rig.client.post("/api/print/start", json={"name": "job.gcode"})


def test_quick_start_runs_script_print_and_zeroes(rig):
    assert start_print(rig).status_code == 200
    state = wait_print(rig, "printing")
    assert state["script"] == "sync_script.py"
    assert rig.client.post("/api/ops/sweep").status_code == 409
    assert wait_until(lambda: any(p > 0 for p in rig.system.pump.snapshot()["commanded"]))
    assert rig.system.snapshot()["print"]["predicted"]["sync"] >= 0
    state = wait_print(rig, "finished")
    assert state["commands_sent"] > 0
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_quick_start_needs_a_uploaded_file(rig):
    time.sleep(1.1)
    assert rig.client.post("/api/print/start", json={"name": "none.gcode"}).status_code == 422


def test_quick_start_refuses_a_file_that_differs_on_the_duet(rig):
    rig.system.duet.print_seconds = 1
    upload(rig)
    rig.system.duet.files["job.gcode"] = GCODE[:-1] + b"X"
    time.sleep(1.1)
    rig.client.post("/api/print/start", json={"name": "job.gcode"})
    state = wait_print(rig, "failed")
    assert "does not match" in state["message"]
    assert rig.system.duet.state == "idle"


def test_quick_start_refused_during_pump_operation(rig):
    upload(rig)
    time.sleep(1.1)
    rig.client.post("/api/ops/purge", json={"duration": 30})
    assert rig.client.post("/api/print/start", json={"name": "job.gcode"}).status_code == 409
    rig.client.post("/api/ops/stop")


def test_stop_print_zeroes_and_cancels(rig):
    rig.system.duet.print_seconds = 30
    start_print(rig)
    wait_print(rig, "printing")
    assert rig.client.post("/api/print/stop").status_code == 200
    assert wait_print(rig, "stopped")["message"] == "Print stopped."
    assert rig.system.duet.state == "idle"
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_emergency_stop_during_print_blocks_the_script(rig):
    rig.system.duet.print_seconds = 30
    upload(rig)
    time.sleep(1.1)
    rig.client.post("/api/print/start", json={"name": "job.gcode"})
    wait_print(rig, "printing")
    rig.system.duet.print_seconds = 30
    rig.client.post("/api/printer/estop")
    wait_print(rig, "stopped")
    assert rig.system.duet.state == "halted"
    time.sleep(0.5)
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_script_failing_to_start_never_starts_the_print(rig, tmp_path):
    script_rig(rig, tmp_path, "import sys; sys.exit(3)")
    upload(rig)
    time.sleep(1.1)
    rig.client.post("/api/print/start", json={"name": "job.gcode"})
    state = wait_print(rig, "failed")
    assert "exited early" in state["message"]
    assert rig.system.duet.state == "idle"


def test_script_dying_during_print_pauses_and_zeroes(rig, tmp_path):
    script_rig(rig, tmp_path, "import time\nprint('Connected.')\ntime.sleep(2.5)\n")
    rig.system.duet.print_seconds = 30
    upload(rig)
    time.sleep(1.1)
    rig.client.post("/api/print/start", json={"name": "job.gcode"})
    state = wait_print(rig, "failed")
    assert "stopped during the print" in state["message"]
    assert rig.system.duet.state == "paused"
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_stop_print_with_nothing_running(rig):
    assert rig.client.post("/api/print/stop").status_code == 409


def test_shutdown_during_print_zeroes(tmp_path):
    app = create_app(Settings(mode="sim", password=PASSWORD, log_dir=str(tmp_path), data_dir=str(tmp_path)))
    with TestClient(app) as client:
        system = app.state.system
        assert system.pump.wait_connected(3)
        client.post("/api/login", json={"password": PASSWORD})
        system.duet.print_seconds = 30
        client.post("/api/jobs", params={"name": "job.gcode"}, content=GCODE)
        time.sleep(1.1)
        client.post("/api/print/start", json={"name": "job.gcode"})
        assert wait_until(lambda: system.runner.snapshot()["state"] == "printing", 15)
        sim = system.sim_serial
    assert set(sim.received[-3:]) == {(0, 0), (1, 0), (2, 0)}


def test_real_mode_needs_a_sync_script(tmp_path):
    from services.print_runner import PrintBusy, PrintRunner

    runner = PrintRunner(Settings(mode="real"), None, None, None, None, None, None, None)
    with pytest.raises(PrintBusy, match="SYNC_SCRIPT"):
        runner.script_path()


def test_reads_the_sync_scripts_real_output_format():
    from services.print_runner import SYNC_LINE, numbers

    line = ("[Sync #12 | clock scale 1.03] t=4.20s | current=(50.10, 40.20, 0.20) | "
            "volume-lookahead=25.000 | future=(60.00, 41.00, 0.20) | ratio=(0.1, 0.2, 0.7) | "
            "flows=(0.24, 0.48, 1.68) | pressures=(120.5, 90.0, 300.25)")
    match = SYNC_LINE.search(line)
    assert match["sync"] == "12"
    assert numbers(match["current"]) == [50.1, 40.2, 0.2]
    assert numbers(match["future"]) == [60.0, 41.0, 0.2]
    assert numbers(match["pressures"]) == [120.5, 90.0, 300.25]


def test_bridge_decodes_frames_as_the_sketch_does():
    from controllers.pump import encode_frame
    from controllers.pump_bridge import PumpBridge

    sent = []
    pump = NS(set_pressure=lambda channel, pressure: sent.append((channel, pressure)))
    bridge = PumpBridge(pump, NS(error=print))
    bridge.open(virtual_port=False)
    bridge.feed(encode_frame(0, 300) + encode_frame(1, 500)[:1])  # Split across two reads
    bridge.feed(encode_frame(1, 500)[1:] + bytes([0x60, 0x8A]))  # Channel 3 is ignored
    bridge.block()
    bridge.feed(encode_frame(2, 700))
    assert sent == [(0, 300), (1, 500)]
    bridge.close()


def test_bridge_shows_channel_masked_frames_reach_channel_0():
    """gcode_sync_volume.py's frames, decoded as the sketch decodes them."""
    from controllers.pump_bridge import PumpBridge

    def script_frame(channel, pressure):
        command = 0x80
        command |= (channel << 13) & 0x03
        command |= (pressure << 1) & 0x1F00
        command |= pressure & 0x007F
        return command.to_bytes(2, "big")

    sent = []
    bridge = PumpBridge(NS(set_pressure=lambda c, p: sent.append((c, p))), NS(error=print))
    bridge.open(virtual_port=False)
    for channel, pressure in enumerate((300, 500, 700)):
        bridge.feed(script_frame(channel, pressure))
    assert sent == [(0, 300), (0, 500), (0, 700)]
    bridge.close()


@pytest.mark.skipif(not hasattr(os, "openpty"), reason="Virtual ports need Linux, such as the Pi")
def test_virtual_port_carries_frames_through_pyserial():
    """Run this on the Pi: it opens the virtual port the way the sync script does."""
    import serial

    from controllers.pump import encode_frame
    from controllers.pump_bridge import PumpBridge

    sent = []
    bridge = PumpBridge(NS(set_pressure=lambda c, p: sent.append((c, p))), NS(error=print))
    path = bridge.open()
    with serial.Serial(path, 115200, timeout=4) as port:
        port.write(encode_frame(1, 500))
        assert wait_until(lambda: sent == [(1, 500)], 2)
    bridge.close()


# --- Printer ---

def test_gcode_reply_and_history(rig):
    assert "X:" in rig.client.post("/api/printer/gcode", json={"command": "M114"}).json()["reply"]
    assert rig.system.snapshot()["history"][-1]["command"] == "M114"


def test_gcode_rejects_line_breaks(rig):
    assert rig.client.post("/api/printer/gcode", json={"command": "M114\nM112"}).status_code == 422


def test_pump_operations_blocked_during_print(rig):
    rig.client.post("/api/printer/gcode", json={"command": 'M32 "job.gcode"'})
    assert rig.client.post("/api/ops/purge", json={"duration": 1}).status_code == 409
    assert rig.client.post("/api/printer/gcode", json={"command": "G1 X10"}).status_code == 409
    assert rig.client.post("/api/printer/gcode", json={"command": "M114"}).status_code == 200


def test_emergency_stop_zeroes_pump_and_halts_duet(rig):
    rig.client.post("/api/ops/purge", json={"duration": 30})
    result = rig.client.post("/api/printer/estop").json()
    assert result == {"pump_zeroed": True, "duet_error": None}
    assert rig.system.duet.state == "halted"
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]
    assert rig.client.post("/api/printer/reset").status_code == 200
    assert rig.system.duet.state == "idle"


def test_emergency_stop_zeroes_pump_when_duet_unreachable(rig):
    rig.client.post("/api/ops/purge", json={"duration": 30})
    rig.system.duet.reachable = False
    result = rig.client.post("/api/printer/estop").json()
    assert result["pump_zeroed"] is True and result["duet_error"]


# --- Access ---

@pytest.mark.parametrize("method,path", [
    ("post", "/api/ops/purge"), ("post", "/api/ops/sweep"), ("post", "/api/ops/stop"),
    ("post", "/api/printer/gcode"), ("post", "/api/printer/estop"),
])
def test_hardware_endpoints_need_login(rig, method, path):
    rig.client.cookies.clear()
    assert getattr(rig.client, method)(path, json={}).status_code == 401
    assert rig.system.pump.snapshot()["commanded"] == [0, 0, 0]


def test_state_needs_login(rig):
    rig.client.cookies.clear()
    assert rig.client.get("/api/state").status_code == 401


def test_wrong_password(rig):
    rig.client.cookies.clear()
    assert rig.client.post("/api/login", json={"password": "nope"}).status_code == 401


def test_forged_session_is_refused(rig):
    rig.client.cookies.clear()
    rig.client.cookies.set("bioprinter_session", "9999999999.abcdef")
    assert rig.client.get("/api/state").status_code == 401


def test_websocket_needs_login(rig):
    from starlette.websockets import WebSocketDisconnect

    rig.client.cookies.clear()
    with pytest.raises(WebSocketDisconnect):
        with rig.client.websocket_connect("/ws"):
            pass


def test_websocket_streams_state(rig):
    with rig.client.websocket_connect("/ws") as socket:
        state = socket.receive_json()
    assert state["pump"]["connected"] is True and state["mode"] == "sim"
