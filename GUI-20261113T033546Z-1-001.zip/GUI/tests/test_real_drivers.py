"""Exercises the non-simulated code paths against stand-ins for the hardware."""

import json
import sys
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest
import serial

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import load_settings
from controllers import pump as pump_module
from controllers.printer import DuetClient, PrinterError
from controllers.pump import PumpController, PumpError
from services.logbook import Logbook


class FakeDuet:
    """Behaves as the RepRapFirmware rr_ HTTP documentation describes."""

    def __init__(self):
        self.password = "secret"
        self.logged_in = False
        self.gcodes = []
        self.files = {}
        self.page_size = 2
        self.reply_seq = 0
        self.reply = ""
        self.model = {
            "state.status": "idle",
            "job.file.fileName": None,
            "move.axes": [
                {"letter": "X", "machinePosition": 1.5},
                {"letter": "Y", "machinePosition": 2.5},
            ],
        }


def make_handler(duet):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, status, body):
            data = body.encode()
            self.send_response(status)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def send_bytes(self, data):
            self.send_response(200)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            url = urlparse(self.path)
            query = {key: values[0] for key, values in parse_qs(url.query).items()}
            data = self.rfile.read(int(self.headers["Content-Length"]))
            if not duet.logged_in:
                self.send(401, "")
            elif query["name"].startswith("0:/gcodes/") and int(query["crc32"], 16) == zlib.crc32(data):
                duet.files[query["name"].split("/")[-1]] = data
                self.send(200, json.dumps({"err": 0}))
            else:
                self.send(200, json.dumps({"err": 1}))

        def do_GET(self):
            url = urlparse(self.path)
            query = {key: values[0] for key, values in parse_qs(url.query).items()}
            if url.path == "/rr_connect":
                good = query.get("password") == duet.password
                duet.logged_in = good
                self.send(200, json.dumps({"err": 0 if good else 1}))
            elif not duet.logged_in:
                self.send(401, "")
            elif url.path == "/rr_gcode":
                duet.gcodes.append(query["gcode"])
                if query["gcode"] == "M115":
                    duet.reply, duet.reply_seq = "FIRMWARE_NAME: RepRapFirmware", duet.reply_seq + 1
                self.send(200, json.dumps({"buff": 200}))
            elif url.path == "/rr_filelist":
                names = sorted(duet.files)
                first = int(query.get("first", 0))
                page = names[first:first + duet.page_size]
                more = first + duet.page_size < len(names)
                entries = [{"type": "f", "name": n, "size": len(duet.files[n])} for n in page]
                entries.append({"type": "d", "name": "folder", "size": 0})
                self.send(200, json.dumps({
                    "dir": query["dir"], "first": first, "files": entries,
                    "next": first + duet.page_size if more else 0, "err": 0,
                }))
            elif url.path == "/rr_download":
                data = duet.files.get(query["name"].split("/")[-1])
                self.send(404, "") if data is None else self.send_bytes(data)
            elif url.path == "/rr_reply":
                self.send(200, duet.reply + "\n")
            elif url.path == "/rr_model":
                key = query["key"]
                result = duet.reply_seq if key == "seqs.reply" else duet.model[key]
                self.send(200, json.dumps({"key": key, "flags": query.get("flags", ""), "result": result}))
            else:
                self.send(404, "")

    return Handler


@pytest.fixture
def duet():
    fake = FakeDuet()
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(fake))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    fake.url = f"http://127.0.0.1:{server.server_address[1]}"
    yield fake
    server.shutdown()
    server.server_close()


def test_duet_status(duet):
    assert DuetClient(duet.url, "secret").status() == {
        "connected": True, "status": "idle", "file": None,
        "position": {"X": 1.5, "Y": 2.5}, "error": None,
    }


def test_duet_gcode_returns_reply(duet):
    assert DuetClient(duet.url, "secret").send_gcode("M115") == "FIRMWARE_NAME: RepRapFirmware"
    assert duet.gcodes == ["M115"]


def test_duet_gcode_with_no_reply(duet, monkeypatch):
    monkeypatch.setattr("controllers.printer.REPLY_WAIT_S", 0.2)
    assert DuetClient(duet.url, "secret").send_gcode("G1 X1") == ""


def test_duet_logs_in_again_after_session_timeout(duet):
    client = DuetClient(duet.url, "secret")
    client.status()
    duet.logged_in = False
    assert client.status()["connected"] is True


def test_duet_wrong_password(duet):
    with pytest.raises(PrinterError, match="password"):
        DuetClient(duet.url, "wrong").status()


def test_duet_emergency_stop_and_reset(duet):
    client = DuetClient(duet.url, "secret")
    client.emergency_stop()
    client.reset()
    assert duet.gcodes == ["M112", "M999"]


def test_duet_unreachable_is_reported():
    with pytest.raises(PrinterError):
        DuetClient("http://127.0.0.1:9", "secret").status()


def test_duet_upload_list_and_download(duet):
    client = DuetClient(duet.url, "secret")
    client.upload_file("a.gcode", b"G1 X1\n", zlib.crc32(b"G1 X1\n"))
    assert duet.files == {"a.gcode": b"G1 X1\n"}
    assert client.download_file("a.gcode") == b"G1 X1\n"
    assert client.download_file("missing.gcode") is None


def test_duet_rejected_upload_is_an_error(duet):
    with pytest.raises(PrinterError, match="rejected"):
        DuetClient(duet.url, "secret").upload_file("a.gcode", b"data", 12345)
    assert duet.files == {}


def test_duet_file_list_follows_pages_and_skips_folders(duet):
    duet.files = {f"{i}.gcode": b"x" * i for i in range(5)}
    assert DuetClient(duet.url, "secret").list_files() == {f"{i}.gcode": i for i in range(5)}


def loop_opener():
    return serial.serial_for_url("loop://", 115200, timeout=0.05)


def test_device_that_is_not_the_pump_is_never_marked_connected(tmp_path, monkeypatch):
    monkeypatch.setattr(pump_module, "HANDSHAKE_TIMEOUT_S", 0.2)
    log = Logbook(str(tmp_path))
    pump = PumpController(loop_opener, log)
    pump.start()
    deadline = time.monotonic() + 3
    while pump.snapshot()["error"] is None and time.monotonic() < deadline:
        time.sleep(0.01)
    assert pump.snapshot()["error"] == "Port opened, but no pump feedback arrived."
    assert pump.connected is False
    with pytest.raises(PumpError):
        pump.set_pressure(0, 100)
    pump.close()
    log.close()


def test_pyserial_port_carries_frames_and_feedback(tmp_path):
    """Real pyserial object: feedback goes in, and frames come out on the wire."""
    log = Logbook(str(tmp_path))
    port = loop_opener()
    port.write(b"10.5,20.0,30.0\r\n")
    pump = PumpController(lambda: port, log)
    pump.start()
    assert pump.wait_connected(2)
    assert pump.snapshot()["measured"] == [10.5, 20.0, 30.0]

    captured = []
    original = port.write
    port.write = lambda data: (captured.append(bytes(data)), original(data))[1]
    pump.set_pressure(1, 1000)
    assert captured == [bytes([0x27, 0xE8])]
    assert pump.zero_all() is True
    pump.close()
    log.close()


def test_real_mode_requires_a_password(monkeypatch):
    monkeypatch.setenv("BIOPRINTER_MODE", "real")
    monkeypatch.delenv("BIOPRINTER_PASSWORD", raising=False)
    with pytest.raises(SystemExit, match="BIOPRINTER_PASSWORD"):
        load_settings()
