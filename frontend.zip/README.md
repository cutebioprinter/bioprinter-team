# Bioprinter GUI

A web interface for the bioprinter. It runs on the Raspberry Pi 5, and lab members use it from a browser. All pump and printer communication stays on the Pi.

**Built so far:** Debug Tools (purge, pressure sweep, flow calibration, G-code console), G-code file upload to the Pi and Duet, Quick Start printing, Home, basic Monitoring, emergency stop, and the lab password.

**Not built yet:** Script Library, pause and resume, charts, and running the repository's print scripts from the GUI.

**Tested so far:** simulated hardware and stand-ins for the Duet and serial port. It has not been run on a Pi, the pump, or a real Duet.

## Run it on a laptop with simulated hardware

You need Python 3.11+ and Node.js.

```bash
# macOS or Linux
cd backend
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m pytest tests
.venv/bin/python -m uvicorn main:app --port 8000
```

```powershell
# Windows
cd backend
python -m venv .venv
.venv\Scripts\pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest tests
.venv\Scripts\python -m uvicorn main:app --port 8000
```

In a second terminal:

```bash
cd frontend
npm install
npm run build
```

Open http://127.0.0.1:8000 and log in with `bioprinter`. That password only applies in simulation.

To work on the interface with live reload, also run `npm run dev` and open http://localhost:5173.

## Deploy on the Raspberry Pi

1. Build the frontend on a laptop with `npm run build`, then copy the whole project to `/home/pi/bioprinter-gui`, including `frontend/dist`.

2. Install the backend:

   ```bash
   cd /home/pi/bioprinter-gui/backend
   python3 -m venv .venv
   .venv/bin/pip install -r requirements.txt
   sudo usermod -aG dialout pi
   ```

3. Create `/home/pi/bioprinter-gui/.env`:

   ```ini
   BIOPRINTER_MODE=real
   BIOPRINTER_PASSWORD=choose-a-lab-password
   PUMP_PORT=auto
   DUET_URL=http://192.168.2.1
   DUET_PASSWORD=reprap
   SYNC_SCRIPT=/home/pi/bioprinter-team/src/gcode_sync_volume.py
   SYNC_FLOW_RATE=2.4
   ```

4. Create `/etc/systemd/system/bioprinter-gui.service`:

   ```ini
   [Unit]
   Description=Bioprinter GUI
   After=network-online.target

   [Service]
   User=pi
   WorkingDirectory=/home/pi/bioprinter-gui/backend
   EnvironmentFile=/home/pi/bioprinter-gui/.env
   ExecStart=/home/pi/bioprinter-gui/backend/.venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
   Restart=on-failure

   [Install]
   WantedBy=multi-user.target
   ```

5. Start it:

   ```bash
   sudo systemctl enable --now bioprinter-gui
   ```

6. Open http://raspberrypi.local:8000 from a computer on the same network. If campus Wi-Fi blocks devices from reaching each other, use a dedicated router for the printer.

The password travels over plain HTTP, so use this only on a network you trust.

### Changing the pump's USB port

`PUMP_PORT=auto` finds the Arduino on any USB socket and refuses to guess if it finds none or more than one. To choose one yourself, set a path in `.env` and restart the service:

```ini
PUMP_PORT=/dev/ttyACM1
```

Run `python3 pump_test_pi.py --list-ports` to see what is connected. Stop the GUI first (`sudo systemctl stop bioprinter-gui`) when running `pump_test_pi.py`, because only one program can hold the pump's port.

### Other settings

| Setting | Default | Meaning |
|---|---|---|
| `MAX_PURGE_S` | `300` | Time limit for a purge with no duration |
| `BIOPRINTER_LOG_DIR` | `logs` | Where the operation log is saved |
| `BIOPRINTER_DATA_DIR` | `data` | Where calibration results are saved |

## Flow calibration

1. Plan the tests, with a pressure for each channel. A test can run one, two or all three channels.
2. Start a test. All channels change together, stay on for the test duration, then go to 0 together.
3. Weigh the output and enter the weight in mg, plus the composition: three numbers that add up to 1, for channels 0, 1 and 2.
4. Save the result, or discard it and repeat the test.

Flow assumes the density of water, so 1 mg = 1 µL. Total flow is the weight divided by the measured on time. Each channel's flow is the total multiplied by its share of the composition. A stopped test saves nothing.

Results are saved to `data/calibration_results.csv`, and the Debug Tools page can download them. Simulated runs save to a separate file, `calibration_results_simulated.csv`.

## Safety behavior

- Hardware operations ask for confirmation. Stop buttons and Emergency Stop act immediately.
- Only one pump operation runs at a time, and pump tools lock while a print is running.
- Operations run on the Pi, so a closed browser or dropped Wi-Fi does not stop or disturb them.
- The pump is commanded to 0 mbar when an operation finishes, stops, or fails, and when the server shuts down.
- A purge with no duration ends at `MAX_PURGE_S`, in case nobody is left at the browser.
- **Emergency Stop** in the GUI commands 0 mbar and sends M112 to the Duet. It needs a working network, so it does not replace the physical stop.
- **Known gap:** the pump sketch has no timeout. If the Pi crashes or loses USB, the Arduino holds its last pressure.

The page also fits the resistance model from `flowrates_to_pressures` in `gcode_sync_volume.py`, giving R1, R2, R3 and RN in mbar per µL/s. It uses every saved result, so delete results from other inks first. It needs at least one test with two or more channels running together. The Monitoring page uses this fit to estimate flow per channel from measured pressure.

## G-code files

The G-code Files page sends a file to the Duet with a CRC32 check, and keeps the same file in `data/gcode` on the Pi. If the Duet refuses it, the Pi's copy does not change. **Check Match** downloads the Duet's copy and compares it with the Pi's. Files added through Duet Web Control only reach the Duet, and the page lists them as such.

## Quick Start

Choosing a file under Quick Start asks for one confirmation, then:

1. Uploads the file to the Pi and the Duet.
2. Compares the two copies byte for byte.
3. Starts `SYNC_SCRIPT` and waits until it reports it is ready.
4. Starts the print with M32.
5. When the print ends, stops the script and sets all channels to 0.

The script gets a virtual serial port instead of the real one. The server passes its commands to the Arduino, so there is no Arduino reset, and live pressures and Emergency Stop keep working. The print is paused if the script exits or the pump is lost. **Stop Print** sets pressure to 0, pauses, then cancels.

`DUET_USB_PORT=auto` finds the Duet's USB port. Set a path if it cannot.

## Opening Duet Web Control through the Pi

The Duet is only on the Pi's Ethernet link, so a laptop on Wi-Fi cannot reach it directly. Forward a port on the Pi:

```bash
sudo apt install socat
```

Create `/etc/systemd/system/duet-forward.service`:

```ini
[Unit]
Description=Forward Duet Web Control
After=network-online.target

[Service]
ExecStart=/usr/bin/socat TCP-LISTEN:8080,fork,reuseaddr TCP:192.168.2.1:80
Restart=always

[Install]
WantedBy=multi-user.target
```

Then run `sudo systemctl enable --now duet-forward` and add `DWC_URL=http://raspberrypi.local:8080` to `.env`. A Duet Web Control link appears beside the page tabs.

This port does not use the GUI's password, so set a password on the Duet with M551 and put the same one in `DUET_PASSWORD`.

## Layout

```text
pump_test_pi.py          Standalone pump test, no GUI needed
proposed_sync_changes/   Sync script changes to evaluate, not in use
backend/
  main.py                App setup
  config.py              Settings and pressure limits
  auth.py                Lab password and sessions
  routers/api.py         HTTP and WebSocket API
  controllers/pump.py    Pump serial communication
  controllers/printer.py Duet HTTP communication
  services/operations.py Purge, sweep, calibration
  services/calibration.py Saved results, flow calculations, model fit
  services/jobs.py       G-code files on the Pi and Duet
  services/print_runner.py Quick Start
  controllers/pump_bridge.py Virtual serial port for the sync script
  services/system.py     Connects everything, reports live state
  simulation/            Simulated Arduino and Duet
frontend/src/            React interface
```
