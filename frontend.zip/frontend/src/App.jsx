import { useEffect, useRef, useState } from "react";
import { api, connectLive } from "./services/api.js";
import ConfirmDialog from "./components/ConfirmDialog.jsx";
import StatusPill, { devicePill } from "./components/StatusPill.jsx";
import Login from "./pages/Login.jsx";
import Home from "./pages/Home.jsx";
import DebugTools from "./pages/DebugTools.jsx";
import GcodeFiles from "./pages/GcodeFiles.jsx";
import ScriptLibrary from "./pages/ScriptLibrary.jsx";
import Monitoring from "./pages/Monitoring.jsx";

const PAGES = [
  { id: "home", label: "Home" },
  { id: "debug", label: "Debug Tools" },
  { id: "files", label: "G-code Files" },
  { id: "scripts", label: "Script Library" },
  { id: "monitoring", label: "Monitoring" },
];

const MAX_LOG_LINES = 500;

export default function App() {
  const [session, setSession] = useState(null);
  const [sessionError, setSessionError] = useState("");

  const loadSession = () =>
    api.session().then(setSession).catch((error) => setSessionError(error.message));

  useEffect(() => {
    loadSession();
  }, []);

  if (sessionError) return <main className="center-screen"><p role="alert">{sessionError}</p></main>;
  if (!session) return <main className="center-screen"><p>Connecting…</p></main>;
  if (!session.authenticated) return <Login onLoggedIn={loadSession} />;
  return <Console session={session} onLoggedOut={loadSession} />;
}

function Console({ session, onLoggedOut }) {
  const [page, setPage] = useState("debug");
  const [state, setState] = useState(null);
  const [linked, setLinked] = useState(true);
  const [log, setLog] = useState([]);
  const [confirmation, setConfirmation] = useState(null);
  const [estopResult, setEstopResult] = useState("");
  const onLoggedOutRef = useRef(onLoggedOut);

  useEffect(
    () =>
      connectLive({
        onOpen: () => setLinked(true),
        onClose: () => setLinked(false),
        onAuthLost: () => onLoggedOutRef.current(),
        onState: (next) => {
          setState(next);
          if (next.log.length) {
            setLog((lines) => {
              const known = new Set(lines.map((line) => line.seq));
              const fresh = next.log.filter((line) => !known.has(line.seq));
              return [...lines, ...fresh].slice(-MAX_LOG_LINES);
            });
          }
        },
      }),
    []
  );

  const emergencyStop = async () => {
    setEstopResult("Sending emergency stop…");
    try {
      const result = await api.emergencyStop();
      const problems = [];
      if (!result.pump_zeroed) problems.push("the pump did not confirm 0 mbar");
      if (result.duet_error) problems.push(`the Duet was not reached (${result.duet_error})`);
      setEstopResult(
        problems.length
          ? `Emergency stop incomplete: ${problems.join(" and ")}. Use the physical stop.`
          : "Emergency stop sent to the pump and the Duet."
      );
    } catch (error) {
      setEstopResult(`Emergency stop failed: ${error.message} Use the physical stop.`);
    }
  };

  const logout = async () => {
    await api.logout();
    onLoggedOut();
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <h1>Bioprinter</h1>
          {session.mode === "sim" && <span className="sim-badge">Simulated hardware</span>}
        </div>
        <div className="topbar-status">
          <StatusPill label="Pi" tone={linked ? "good" : "bad"} value={linked ? "Connected" : "Lost"} />
          <StatusPill label="Duet" {...devicePill(session.mode, state?.duet.connected, state?.duet.status)} />
          <StatusPill label="Pump" {...devicePill(session.mode, state?.pump.connected)} />
        </div>
        <button className="estop" onClick={emergencyStop}>
          Emergency Stop
        </button>
      </header>

      <nav className="tabs" aria-label="Pages">
        {PAGES.map(({ id, label }) => (
          <button key={id} className={page === id ? "tab active" : "tab"} onClick={() => setPage(id)}>
            {label}
          </button>
        ))}
        {session.dwcUrl && (
          <a className="tab tab-link" href={session.dwcUrl} target="_blank" rel="noreferrer">
            Duet Web Control
          </a>
        )}
        <button className="tab logout" onClick={logout}>
          Log out
        </button>
      </nav>

      {!linked && (
        <div className="banner warn" role="alert">
          Live connection to the Pi is lost. Anything already running keeps going on the Pi. Reconnecting…
        </div>
      )}
      {state && !state.operation.pressure_safe && (
        <div className="banner danger" role="alert">
          The last operation could not command 0 mbar. Pressure may still be applied. Check the pump now.
        </div>
      )}
      {estopResult && (
        <div className="banner danger" role="status">
          <span>{estopResult}</span>
          <button className="link" onClick={() => setEstopResult("")}>Dismiss</button>
        </div>
      )}

      <main className="page">
        {!state ? (
          <p>Waiting for the Pi…</p>
        ) : (
          <>
            {page === "home" && <Home state={state} onOpenDebug={() => setPage("debug")} confirm={setConfirmation} />}
            {page === "debug" && <DebugTools state={state} session={session} confirm={setConfirmation} />}
            {page === "files" && (
              <GcodeFiles version={state.jobs_version} state={state} confirm={setConfirmation} />
            )}
            {page === "scripts" && <ScriptLibrary />}
            {page === "monitoring" && <Monitoring state={state} log={log} />}
          </>
        )}
      </main>

      {confirmation && <ConfirmDialog {...confirmation} onClose={() => setConfirmation(null)} />}
    </div>
  );
}
