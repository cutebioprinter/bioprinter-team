import { useState } from "react";
import { api } from "../services/api.js";
import OperationStatus from "./OperationStatus.jsx";
import StopButton from "./StopButton.jsx";

const CHANNELS = [0, 1, 2];
const DEADBAND_MBAR = 10; // The pump sketch treats anything lower as off
const DEFAULT_TESTS = [200, 160, 120, 100, 80, 40].map((pressure) => [String(pressure), "0", "0"]);

function pressureValid(text, maxPressure) {
  const value = Number(text);
  return (
    text.trim() !== "" &&
    Number.isInteger(value) &&
    (value === 0 || (value >= DEADBAND_MBAR && value <= maxPressure))
  );
}

function testValid(test, maxPressure) {
  return test.every((text) => pressureValid(text, maxPressure)) && test.some((text) => Number(text) > 0);
}

function pressureHint(maxPressure) {
  return `Each pressure must be 0, or ${DEADBAND_MBAR} to ${maxPressure} mbar, and at least one must be above 0.`;
}

function PressureInputs({ test, label, onChange }) {
  return CHANNELS.map((channel) => (
    <label key={channel}>
      <span className="field-label">Channel {channel}</span>
      <input
        inputMode="numeric"
        aria-label={`${label} channel ${channel} pressure in mbar`}
        value={test[channel]}
        onChange={(event) => onChange(channel, event.target.value)}
      />
    </label>
  ));
}

export function parseComposition(text) {
  const parts = text.split(/[\s,]+/).filter(Boolean).map(Number);
  const valid =
    parts.length === 3 &&
    parts.every((part) => Number.isFinite(part) && part >= 0) &&
    Math.abs(parts.reduce((sum, part) => sum + part, 0) - 1) <= 0.0101;
  return valid ? parts : null;
}

export default function Calibration({ operation, measured, blocked, running, confirm, maxPressure }) {
  const mine = running && operation.kind === "calibration";

  return (
    <section className="card wide">
      <h2>Flow Calibration</h2>
      <p className="muted">
        Runs each test for an exact time so you can weigh what came out. Flow rates are calculated from the weight.
      </p>
      {!mine && (
        <PlanForm
          operation={operation}
          measured={measured}
          blocked={blocked}
          confirm={confirm}
          maxPressure={maxPressure}
        />
      )}
      {mine && operation.phase === "ready" && (
        <ReadyStep key={operation.test_key} operation={operation} maxPressure={maxPressure} />
      )}
      {mine && operation.phase === "testing" && (
        <>
          <OperationStatus operation={operation} kind="calibration" measured={measured} />
          <div className="button-row"><StopButton label="Stop Calibration" /></div>
        </>
      )}
      {mine && operation.phase === "weigh" && <WeighStep key={operation.test_key} operation={operation} />}
    </section>
  );
}

function PlanForm({ operation, measured, blocked, confirm, maxPressure }) {
  const [duration, setDuration] = useState("50");
  const [tests, setTests] = useState(DEFAULT_TESTS);

  const seconds = Number(duration);
  const durationValid = seconds > 0 && seconds <= 3600;
  const testsValid = tests.length > 0 && tests.every((test) => testValid(test, maxPressure));

  const changePressure = (index, channel, value) =>
    setTests((all) =>
      all.map((test, row) => (row === index ? test.map((old, c) => (c === channel ? value : old)) : test))
    );

  const start = () =>
    confirm({
      title: "Start flow calibration?",
      body: `${tests.length} tests of ${seconds} s each. No pressure is applied until you start each test.`,
      actionLabel: "Start Calibration",
      onConfirm: () => api.calibrate(seconds, tests.map((test) => test.map(Number))),
    });

  return (
    <>
      <label className="short-field">
        Test duration (seconds)
        <input inputMode="decimal" value={duration} onChange={(event) => setDuration(event.target.value)} />
      </label>
      <div className="test-plan">
        <p className="field-label">Planned tests (mbar)</p>
        {tests.map((test, index) => (
          <div className="test-row" key={index}>
            <span className="test-number">Test {index + 1}</span>
            <PressureInputs
              test={test}
              label={`Test ${index + 1}`}
              onChange={(channel, value) => changePressure(index, channel, value)}
            />
            <button
              className="quiet"
              aria-label={`Remove test ${index + 1}`}
              onClick={() => setTests((all) => all.filter((_, row) => row !== index))}
            >
              Remove
            </button>
          </div>
        ))}
        {tests.length < 20 && (
          <button
            className="quiet add-test"
            onClick={() => setTests((all) => [...all, all.length ? [...all[all.length - 1]] : ["100", "0", "0"]])}
          >
            Add Test
          </button>
        )}
      </div>
      {!durationValid && <p className="error">Enter a duration from 0 to 3600 seconds.</p>}
      {!testsValid && <p className="error">{tests.length ? pressureHint(maxPressure) : "Add at least one test."}</p>}
      <OperationStatus operation={operation} kind="calibration" measured={measured} />
      <div className="button-row">
        <button className="primary" disabled={Boolean(blocked) || !durationValid || !testsValid} onClick={start}>
          Start Calibration
        </button>
      </div>
      {blocked && <p className="muted">{blocked}</p>}
    </>
  );
}

function ReadyStep({ operation, maxPressure }) {
  const [test, setTest] = useState(operation.next_pressures.map(String));
  const [error, setError] = useState("");
  const valid = testValid(test, maxPressure);

  const change = (channel, value) => setTest((old) => old.map((text, c) => (c === channel ? value : text)));

  const start = () => {
    setError("");
    api.startTest(test.map(Number)).catch((failure) => setError(failure.message));
  };

  return (
    <div className="step">
      <h3>Test {operation.step} of {operation.total_steps}</h3>
      <p>Put a clean container under the nozzle and zero the scale. Pressure stays off until you start.</p>
      <div className="test-row">
        <PressureInputs test={test} label="This test" onChange={change} />
      </div>
      {!valid && <p className="error">{pressureHint(maxPressure)}</p>}
      {error && <p className="error" role="alert">{error}</p>}
      <div className="button-row">
        <button className="primary" disabled={!valid} onClick={start}>Start Test</button>
        <StopButton label="Stop Calibration" />
      </div>
    </div>
  );
}

function WeighStep({ operation }) {
  const { pending, step, total_steps: total } = operation;
  const activeChannels = pending.pressures.filter((pressure) => pressure > 0).length;
  const onlyChannel = pending.pressures.findIndex((pressure) => pressure > 0);

  // With one channel on, all of the fluid came from it.
  const [composition, setComposition] = useState(
    activeChannels === 1 ? CHANNELS.map((c) => (c === onlyChannel ? 1 : 0)).join(", ") : ""
  );
  const [weight, setWeight] = useState("");
  const [error, setError] = useState("");

  const weightMg = Number(weight);
  const weightValid = weight.trim() !== "" && weightMg >= 0;
  const parts = parseComposition(composition);
  const compositionTyped = composition.trim() !== "";
  const flow = weightValid ? weightMg / pending.on_time_s : null;

  const save = () => {
    setError("");
    api.saveResult(weightMg, parts).catch((failure) => setError(failure.message));
  };

  const repeat = () => {
    setError("");
    api.repeatTest().catch((failure) => setError(failure.message));
  };

  return (
    <div className="step">
      <h3>Test {step} of {total}: enter the result</h3>
      <p>
        Pressure was on for {pending.on_time_s.toFixed(2)} s at {pending.pressures.join(", ")} mbar. All channels are
        now at 0.
      </p>
      <div className="result-fields">
        <label>
          Weight (mg)
          <input inputMode="decimal" value={weight} autoFocus onChange={(event) => setWeight(event.target.value)} />
        </label>
        <label>
          Composition (channels 0, 1, 2)
          <input
            value={composition}
            placeholder="0.1, 0.24, 0.66"
            onChange={(event) => setComposition(event.target.value)}
          />
        </label>
      </div>
      {weight.trim() !== "" && !weightValid && <p className="error">Enter the weight in mg.</p>}
      {compositionTyped && !parts && <p className="error">Enter 3 numbers that add up to 1.</p>}
      {flow !== null && (
        <p>
          Total flow: <strong>{flow.toFixed(3)} µL/s</strong>
          {parts && <span> ({parts.map((part) => (part * flow).toFixed(3)).join(", ")} µL/s by channel)</span>}
        </p>
      )}
      {error && <p className="error" role="alert">{error}</p>}
      <div className="button-row">
        <button className="primary" disabled={!weightValid || !parts} onClick={save}>
          {step === total ? "Save Result" : "Save and Continue"}
        </button>
        <button onClick={repeat}>Discard and Repeat Test</button>
        <StopButton label="End Without Saving" />
      </div>
    </div>
  );
}
