import { useEffect, useState } from "react";
import { api } from "../services/api.js";

export default function CalibrationResults({ version, confirm }) {
  const [results, setResults] = useState([]);
  const [model, setModel] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let current = true;
    Promise.all([api.listResults(), api.calibrationModel()])
      .then(([rows, fitted]) => {
        if (current) {
          setResults(rows);
          setModel(fitted);
          setError("");
        }
      })
      .catch((failure) => current && setError(failure.message));
    return () => {
      current = false;
    };
  }, [version]);

  const remove = (result) =>
    confirm({
      title: "Delete this result?",
      body: `The ${result.weight_mg} mg result from ${result.recorded_at} will be removed permanently.`,
      actionLabel: "Delete Result",
      onConfirm: () => api.deleteResult(result.id),
    });

  return (
    <section className="card wide">
      <div className="card-heading">
        <h2>Calibration Results</h2>
        {results.length > 0 && <a href="/api/calibration/results.csv" download>Download CSV</a>}
      </div>
      {error && <p className="error" role="alert">{error}</p>}
      <p className="muted">Flow assumes the density of water, so 1 mg = 1 µL.</p>
      {results.length === 0 ? (
        <p className="muted">No results saved yet.</p>
      ) : (
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Saved</th>
                <th className="num">Pressure (mbar)</th>
                <th className="num">On time (s)</th>
                <th className="num">Weight (mg)</th>
                <th className="num">Composition</th>
                <th className="num">Total flow (µL/s)</th>
                <th className="num">Flow by channel (µL/s)</th>
                <th><span className="visually-hidden">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {results.map((result) => (
                <tr key={result.id}>
                  <td className="nowrap">{result.recorded_at}</td>
                  <td className="num nowrap">{result.pressures.join(", ")}</td>
                  <td className="num">{result.on_time_s.toFixed(2)}</td>
                  <td className="num">{result.weight_mg}</td>
                  <td className="num nowrap">{result.composition.join(", ")}</td>
                  <td className="num">{result.flow_total.toFixed(3)}</td>
                  <td className="num nowrap">{result.flows.map((flow) => flow.toFixed(3)).join(", ")}</td>
                  <td>
                    <button className="quiet" onClick={() => remove(result)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {model && results.length > 0 && <ModelSummary model={model} />}
    </section>
  );
}

function ModelSummary({ model }) {
  return (
    <div className="step">
      <h3>Resistance model</h3>
      {!model.ready ? (
        <p className="muted">{model.reason}</p>
      ) : (
        <>
          <p className="muted">
            Fitted from all {model.tests} saved results, in mbar per µL/s. Delete results from other inks first.
            These match R1, R2, R3 and RN in gcode_sync_volume.py.
          </p>
          <dl className="readings">
            {model.resistances.map((value, channel) => (
              <div key={channel}>
                <dt>R{channel + 1} (channel {channel})</dt>
                <dd>{value.toFixed(2)}</dd>
              </div>
            ))}
            <div><dt>RN (shared)</dt><dd>{model.shared_resistance.toFixed(2)}</dd></div>
            <div><dt>Typical error</dt><dd>{model.rms_error_mbar.toFixed(1)} mbar</dd></div>
            <div><dt>R²</dt><dd>{model.r_squared === null ? "—" : model.r_squared.toFixed(3)}</dd></div>
          </dl>
          {!model.physical && (
            <p className="error">A resistance came out negative, so this fit is not physically meaningful yet.</p>
          )}
        </>
      )}
    </div>
  );
}
