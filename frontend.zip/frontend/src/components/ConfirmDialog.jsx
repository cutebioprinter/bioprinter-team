import { useEffect, useRef, useState } from "react";

export default function ConfirmDialog({ title, body, actionLabel, onConfirm, onClose }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const cancelRef = useRef(null);

  useEffect(() => {
    cancelRef.current?.focus();  // Enter must not start hardware by accident
    const onKey = (event) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const confirm = async () => {
    setBusy(true);
    setError("");
    try {
      await onConfirm();
      onClose();
    } catch (failure) {
      setError(failure.message);
      setBusy(false);
    }
  };

  return (
    <div className="dialog-backdrop">
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
        <h2 id="dialog-title">{title}</h2>
        <p>{body}</p>
        {error && <p className="error" role="alert">{error}</p>}
        <div className="button-row end">
          <button ref={cancelRef} onClick={onClose}>Cancel</button>
          <button className="primary" onClick={confirm} disabled={busy}>{actionLabel}</button>
        </div>
      </div>
    </div>
  );
}
