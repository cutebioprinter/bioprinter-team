import { useEffect, useRef, useState } from "react";
import { api } from "../services/api.js";

export default function GcodeConsole({ history }) {
  const [command, setCommand] = useState("");
  const [recall, setRecall] = useState(-1);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const outputRef = useRef(null);

  useEffect(() => {
    const output = outputRef.current;
    if (output) output.scrollTop = output.scrollHeight;
  }, [history.length]);

  const send = async (event) => {
    event.preventDefault();
    const text = command.trim();
    if (!text) return;
    setBusy(true);
    setError("");
    try {
      await api.gcode(text);
      setCommand("");
      setRecall(-1);
    } catch (failure) {
      setError(failure.message);
    }
    setBusy(false);
  };

  // Up and Down step through earlier commands, as in a terminal.
  const onKeyDown = (event) => {
    if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
    event.preventDefault();
    const next = event.key === "ArrowUp" ? recall + 1 : recall - 1;
    if (next < 0) {
      setRecall(-1);
      setCommand("");
    } else if (next < history.length) {
      setRecall(next);
      setCommand(history[history.length - 1 - next].command);
    }
  };

  return (
    <section className="card wide">
      <h2>G-code Console</h2>
      <div className="console-output" ref={outputRef} aria-live="polite">
        {history.length === 0 && <p className="muted">No commands sent yet.</p>}
        {history.map((entry) => (
          <div key={entry.time}>
            <div className="console-command">&gt; {entry.command}</div>
            {entry.reply && <div className="console-reply">{entry.reply}</div>}
            {entry.error && <div className="console-error">{entry.error}</div>}
          </div>
        ))}
      </div>
      <form className="console-input" onSubmit={send}>
        <input
          aria-label="G-code command"
          value={command}
          placeholder="For example M114"
          autoComplete="off"
          spellCheck="false"
          onChange={(event) => setCommand(event.target.value)}
          onKeyDown={onKeyDown}
        />
        <button className="primary" disabled={busy || !command.trim()}>Send Command</button>
      </form>
      {error && <p className="error" role="alert">{error}</p>}
    </section>
  );
}
