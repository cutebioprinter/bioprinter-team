const STATUS_TEXT = {
  running: "Running",
  waiting: "Waiting for you",
  completed: "Finished",
  stopped: "Stopped",
  error: "Error",
};

/** Progress for one operation, shown only on that operation's own card. */
export default function OperationStatus({ operation, kind, measured }) {
  if (operation.kind !== kind) return <p className="muted">Not running.</p>;

  const percent = operation.progress == null ? null : Math.min(100, Math.round(operation.progress * 100));
  const running = operation.status === "running";

  return (
    <div className="op-status">
      <p className={`op-line ${operation.status}`}>
        <strong>{STATUS_TEXT[operation.status]}</strong>
        {operation.message && !["completed", "stopped"].includes(operation.status) && (
          <span> — {operation.message}</span>
        )}
      </p>
      {running && (
        <table className="compact">
          <thead>
            <tr>
              <th>mbar</th>
              {operation.targets.map((_, channel) => <th className="num" key={channel}>Channel {channel}</th>)}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Target</td>
              {operation.targets.map((value, channel) => <td className="num" key={channel}>{value}</td>)}
            </tr>
            <tr>
              <td>Measured</td>
              {measured.map((value, channel) => <td className="num" key={channel}>{value.toFixed(1)}</td>)}
            </tr>
          </tbody>
        </table>
      )}
      {running && percent !== null && (
        <div className="progress" role="progressbar" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}>
          <div style={{ width: `${percent}%` }} />
        </div>
      )}
    </div>
  );
}
