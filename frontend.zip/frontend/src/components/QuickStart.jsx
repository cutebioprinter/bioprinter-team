import { useRef, useState } from "react";
import { api } from "../services/api.js";

const STATE_TEXT = {
  checking: "Checking the file",
  starting_script: "Starting the sync script",
  starting_print: "Starting the print",
  printing: "Printing",
  stopping: "Stopping",
  finished: "Finished",
  stopped: "Stopped",
  failed: "Failed",
};

const ACTIVE = ["checking", "starting_script", "starting_print", "printing", "stopping"];

export default function QuickStart({ files, state, canPrint, confirm }) {
  const inputRef = useRef(null);
  const [error, setError] = useState("");
  const { print } = state;
  const active = ACTIVE.includes(print.state);

  const choose = (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const replacing = files.some((known) => known.name === file.name);
    confirm({
      title: `Print ${file.name}?`,
      body: `${replacing ? "This replaces the existing file. " : ""}It uploads to the Pi and the Duet, then the printer homes and starts moving, and the sync script controls the pump.`,
      actionLabel: "Upload and Print",
      onConfirm: async () => {
        await api.uploadJob(file, replacing);
        await api.startPrint(file.name);
      },
    });
    event.target.value = "";
  };

  const stop = () => {
    setError("");
    api.stopPrint().catch((failure) => setError(failure.message));
  };

  return (
    <section className="card wide">
      <h2>Quick Start</h2>
      <p className="muted">
        Choose a file to upload it, confirm the Pi and Duet match, start the sync script, and start the print.
      </p>
      <label className="short-field">
        G-code file to print
        <input ref={inputRef} type="file" accept=".gcode,.gc,.g,.nc" disabled={!canPrint} onChange={choose} />
      </label>
      {!canPrint && !active && <p className="muted">The pump and Duet must be connected and idle.</p>}
      {print.state !== "idle" && (
        <p className={`op-line ${print.state === "failed" ? "error" : print.state === "finished" ? "completed" : ""}`}>
          <strong>{STATE_TEXT[print.state]}</strong>
          {print.file && <span> — {print.file}</span>}
          {print.state === "failed" && <span>: {print.message}</span>}
        </p>
      )}
      {active && <p className="muted">Sync script: {print.script}. Pump commands sent: {print.commands_sent}.</p>}
      {error && <p className="error" role="alert">{error}</p>}
      {active && (
        <div className="button-row">
          <button className="stop" onClick={stop}>Stop Print</button>
        </div>
      )}
    </section>
  );
}
