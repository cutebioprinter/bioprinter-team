export default function StatusPill({ label, value, tone }) {
  return (
    <span className={`pill ${tone}`}>
      <span className="dot" aria-hidden="true" />
      <span className="pill-label">{label}</span>
      <span>{value}</span>
    </span>
  );
}

/** Pill text for a hardware device. Simulated devices never read as really connected. */
export function devicePill(mode, connected, connectedText = "Connected") {
  if (!connected) return { tone: "bad", value: "Disconnected" };
  if (mode === "sim") return { tone: "sim", value: `Simulated (${connectedText.toLowerCase()})` };
  return { tone: "good", value: connectedText };
}
