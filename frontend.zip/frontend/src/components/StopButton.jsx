import { useState } from "react";
import { api } from "../services/api.js";

export default function StopButton({ label, visible = true }) {
  const [error, setError] = useState("");
  if (!visible) return null;

  const stop = () => {
    setError("");
    api.stop().catch((failure) => setError(failure.message));
  };

  return (
    <>
      <button className="stop" onClick={stop}>{label}</button>
      {error && <p className="error" role="alert">{error}</p>}
    </>
  );
}
