import { useState } from "react";
import { api } from "../services/api.js";
import OperationStatus from "../components/OperationStatus.jsx";
import GcodeConsole from "../components/GcodeConsole.jsx";
import StopButton from "../components/StopButton.jsx";
import Calibration from "../components/Calibration.jsx";
import CalibrationResults from "../components/CalibrationResults.jsx";

const PRINTING_STATES = ["processing", "paused", "pausing", "resuming", "busy"];
const CHANNELS = [0, 1, 2];

export default function DebugTools({ state, session, confirm }) {
  const { operation, pump, duet } = state;
  const running = operation.status === "running" || operation.status === "waiting";
  const printing = PRINTING_STATES.includes(duet.status);

  let blocked = "";
  if (!pump.connected) blocked = "The pump is not connected.";
  else if (printing) blocked = "A print is running, so pump tools are locked.";
  else if (running) blocked = "Another operation is running.";

  const shared = { operation, measured: pump.measured, blocked, running, confirm };

  return (
    <div className="grid">
      <Purge {...shared} session={session} />
      <Sweep {...shared} maxPressure={session.maxPressure} />
      <Calibration {...shared} maxPressure={session.maxPressure} />
      <CalibrationResults version={state.calibration_version} confirm={confirm} />
      <GcodeConsole history={state.history} />
    </div>
  );
}

function describeChannels(channels) {
  const names = channels.join(" and ");
  return channels.length === 1 ? `Channel ${names} goes` : `Channels ${names} go`;
}

function Purge({ operation, measured, blocked, running, confirm, session }) {
  const [duration, setDuration] = useState("");
  const [channels, setChannels] = useState([0]);
  const seconds = duration.trim() === "" ? null : Number(duration);
  const durationValid = seconds === null || (seconds > 0 && seconds <= 3600);
  const mine = running && operation.kind === "purge";

  const toggle = (channel) =>
    setChannels((chosen) =>
      chosen.includes(channel) ? chosen.filter((c) => c !== channel) : [...chosen, channel].sort()
    );

  const start = () =>
    confirm({
      title: "Start purge?",
      body:
        seconds === null
          ? `${describeChannels(channels)} to ${session.maxPressure} mbar until you stop it, or after ${session.maxPurgeSeconds} s at most.`
          : `${describeChannels(channels)} to ${session.maxPressure} mbar for ${seconds} s.`,
      actionLabel: "Start Purge",
      onConfirm: () => api.purge(channels, seconds),
    });

  return (
    <section className="card">
      <h2>Purge</h2>
      <p className="muted">Selected channels at maximum pressure.</p>
      <fieldset className="channel-choice" disabled={mine}>
        <legend>Channels</legend>
        {CHANNELS.map((channel) => (
          <label key={channel}>
            <input type="checkbox" checked={channels.includes(channel)} onChange={() => toggle(channel)} />
            Channel {channel}
          </label>
        ))}
      </fieldset>
      <label>
        Duration in seconds (optional)
        <input
          inputMode="decimal"
          value={duration}
          placeholder="Until stopped"
          onChange={(event) => setDuration(event.target.value)}
        />
      </label>
      {!durationValid && <p className="error">Enter a duration from 0 to 3600 seconds.</p>}
      {channels.length === 0 && <p className="error">Choose at least one channel.</p>}
      <OperationStatus operation={operation} kind="purge" measured={measured} />
      <div className="button-row">
        <button
          className="primary"
          disabled={Boolean(blocked) || !durationValid || channels.length === 0}
          onClick={start}
        >
          Start Purge
        </button>
        <StopButton label="Stop Purge" visible={mine} />
      </div>
      {blocked && !mine && <p className="muted">{blocked}</p>}
    </section>
  );
}

function Sweep({ operation, measured, blocked, running, confirm, maxPressure }) {
  const mine = running && operation.kind === "sweep";

  const start = () =>
    confirm({
      title: "Start pressure sweep?",
      body: `Channel 0 rises from 8 to ${maxPressure} mbar in a few seconds, holds for 1 second, then returns to 0.`,
      actionLabel: "Start Pressure Sweep",
      onConfirm: api.sweep,
    });

  return (
    <section className="card">
      <h2>Pressure Sweep</h2>
      <p className="muted">Channel 0 from 8 to {maxPressure} mbar in steps of 10.</p>
      <OperationStatus operation={operation} kind="sweep" measured={measured} />
      <div className="button-row">
        <button className="primary" disabled={Boolean(blocked)} onClick={start}>Start Pressure Sweep</button>
        <StopButton label="Stop Sweep" visible={mine} />
      </div>
      {blocked && !mine && <p className="muted">{blocked}</p>}
    </section>
  );
}
