import { useEffect, useRef, useState } from "react";
import { api } from "../services/api.js";
import QuickStart from "../components/QuickStart.jsx";

const STATE_TEXT = {
  same_size: { text: "On both (same size)", tone: "good" },
  missing_on_duet: { text: "Missing from the Duet", tone: "bad" },
  different: { text: "Different on the Duet", tone: "bad" },
  only_on_duet: { text: "Only on the Duet, not the Pi", tone: "bad" },
  unknown: { text: "Duet not reachable", tone: "muted" },
};

const CHECK_TEXT = {
  match: { text: "Checked: identical", tone: "good" },
  different: { text: "Checked: DIFFERENT", tone: "bad" },
  missing_on_duet: { text: "Checked: missing from the Duet", tone: "bad" },
};

function formatSize(bytes) {
  return bytes < 1_000_000 ? `${(bytes / 1000).toFixed(1)} kB` : `${(bytes / 1_000_000).toFixed(1)} MB`;
}

export default function GcodeFiles({ version, state, confirm }) {
  const [files, setFiles] = useState([]);
  const [duetError, setDuetError] = useState("");
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const [checks, setChecks] = useState({});
  const inputRef = useRef(null);

  const load = () =>
    api
      .listJobs()
      .then((result) => {
        setFiles(result.files);
        setDuetError(result.duet_error || "");
      })
      .catch((failure) => setError(failure.message));

  useEffect(() => {
    load();
  }, [version]);

  const send = async (file, overwrite) => {
    setUploading(true);
    setError("");
    setMessage("");
    try {
      await api.uploadJob(file, overwrite);
      setMessage(`${file.name} is on the Pi and the Duet.`);
      setChecks((old) => ({ ...old, [file.name]: undefined }));
      await load();
    } catch (failure) {
      setError(failure.message);
    }
    setUploading(false);
    if (inputRef.current) inputRef.current.value = "";
  };

  const choose = (event) => {
    const file = event.target.files[0];
    if (!file) return;
    if (files.some((known) => known.name === file.name)) {
      confirm({
        title: `Replace ${file.name}?`,
        body: "The copies on the Pi and the Duet will both be replaced.",
        actionLabel: "Replace File",
        onConfirm: () => send(file, true),
      });
      event.target.value = "";
    } else {
      send(file, false);
    }
  };

  const canPrint = state.pump.connected && state.duet.connected && state.duet.status === "idle"
    && !["checking", "starting_script", "starting_print", "printing", "stopping"].includes(state.print.state)
    && !["running", "waiting"].includes(state.operation.status);

  const printExisting = (name) =>
    confirm({
      title: `Print ${name}?`,
      body: "The printer will home and start moving, and the sync script will control the pump.",
      actionLabel: "Start Print",
      onConfirm: () => api.startPrint(name),
    });

  const check = async (name) => {
    setChecks((old) => ({ ...old, [name]: "checking" }));
    setError("");
    try {
      const { result } = await api.checkJob(name);
      setChecks((old) => ({ ...old, [name]: result }));
    } catch (failure) {
      setChecks((old) => ({ ...old, [name]: undefined }));
      setError(failure.message);
    }
  };

  return (
    <div className="grid">
      <QuickStart files={files} state={state} canPrint={canPrint} confirm={confirm} />
      <section className="card wide">
        <h2>G-code Files</h2>
        <p className="muted">
          Uploading here puts the same file on the Pi and the Duet, so the sync scripts and the printer use the same
          G-code. Files added through Duet Web Control only reach the Duet.
        </p>
        <label className="short-field">
          Upload a G-code file
          <input ref={inputRef} type="file" accept=".gcode,.gc,.g,.nc" disabled={uploading} onChange={choose} />
        </label>
        {uploading && <p>Sending to the Duet…</p>}
        {message && <p className="op-line completed">{message}</p>}
        {error && <p className="error" role="alert">{error}</p>}
        {duetError && <p className="error">{duetError}</p>}

        {files.length === 0 ? (
          <p className="muted">No files yet.</p>
        ) : (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>File</th>
                  <th className="num">Size</th>
                  <th>Uploaded</th>
                  <th>Status</th>
                  <th><span className="visually-hidden">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {files.map((file) => {
                  const checked = CHECK_TEXT[checks[file.name]];
                  const shown = checked || STATE_TEXT[file.state];
                  return (
                    <tr key={file.name}>
                      <td>{file.name}</td>
                      <td className="num nowrap">{formatSize(file.size)}</td>
                      <td className="nowrap">{file.uploaded_at || "—"}</td>
                      <td className={`state-${shown.tone}`}>{shown.text}</td>
                      <td>
                        {file.crc32 && (
                          <div className="button-row nowrap">
                            <button
                              className="quiet"
                              disabled={checks[file.name] === "checking"}
                              onClick={() => check(file.name)}
                            >
                              {checks[file.name] === "checking" ? "Checking…" : "Check Match"}
                            </button>
                            <button
                              className="quiet"
                              aria-label={`Print ${file.name}`}
                              disabled={!canPrint}
                              onClick={() => printExisting(file.name)}
                            >
                              Print
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
