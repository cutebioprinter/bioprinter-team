import { useState } from "react";
import { api } from "../services/api.js";
import StatusPill, { devicePill } from "../components/StatusPill.jsx";

const OPERATION_NAMES = { purge: "Purge", sweep: "Pressure sweep", calibration: "Flow calibration" };

export default function Home({ state, onOpenDebug, confirm }) {
  const { duet, pump, operation } = state;
  const active = operation.status === "running" || operation.status === "waiting";
  const [error, setError] = useState("");

  const stop = () => {
    setError("");
    api.stop().catch((failure) => setError(failure.message));
  };

  const resetDuet = () =>
    confirm({
      title: "Reset the Duet?",
      body: "This restarts the Duet after an emergency stop. Axes will need homing again.",
      actionLabel: "Reset Duet",
      onConfirm: api.resetDuet,
    });

  return (
    <div className="grid">
      <section className="card">
        <h2>Printer</h2>
        <p>
          <StatusPill label="Duet" {...devicePill(state.mode, duet.connected, duet.status)} />
        </p>
        {!duet.connected && duet.error && <p className="error">{duet.error}</p>}
        <p>{duet.file ? `Printing ${duet.file}` : "No print running."}</p>
        {duet.status === "halted" && <button onClick={resetDuet}>Reset Duet</button>}
      </section>

      <section className="card">
        <h2>Pump</h2>
        <p>
          <StatusPill label="Pump" {...devicePill(state.mode, pump.connected)} />
        </p>
        {!pump.connected && pump.error && <p className="error">{pump.error}</p>}
        <p>Measured: {pump.measured.map((value) => `${value.toFixed(0)} mbar`).join(" · ")}</p>
      </section>

      <section className="card">
        <h2>Current activity</h2>
        <p>{active ? `${OPERATION_NAMES[operation.kind]}: ${operation.message || "running"}` : "Nothing running."}</p>
        {state.print.script && <p>Sync script: {state.print.script} ({state.print.state})</p>}
        {error && <p className="error" role="alert">{error}</p>}
        <div className="button-row">
          {active && <button className="stop" onClick={stop}>Stop Debug Operation</button>}
          <button onClick={onOpenDebug}>Open Debug Tools</button>
        </div>
      </section>
    </div>
  );
}
