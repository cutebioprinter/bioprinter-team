import { useEffect, useRef } from "react";

export default function Monitoring({ state, log }) {
  const { pump, duet, flow_estimate: estimate } = state;
  const logRef = useRef(null);

  useEffect(() => {
    const element = logRef.current;
    if (element) element.scrollTop = element.scrollHeight;
  }, [log.length]);

  return (
    <div className="grid">
      <section className="card">
        <h2>Pump channels</h2>
        <table>
          <thead>
            <tr><th>Channel</th><th className="num">Commanded (mbar)</th><th className="num">Measured (mbar)</th><th className="num">Est. flow (µL/s)</th></tr>
          </thead>
          <tbody>
            {pump.measured.map((measured, channel) => (
              <tr key={channel}>
                <td>{channel}</td>
                <td className="num">{pump.commanded[channel]}</td>
                <td className="num">{measured.toFixed(1)}</td>
                <td className="num">{estimate.flows ? estimate.flows[channel].toFixed(2) : "—"}</td>
              </tr>
            ))}
            <tr className="total-row">
              <td colSpan={3}>Total</td>
              <td className="num">{estimate.flows ? estimate.total.toFixed(2) : "—"}</td>
            </tr>
          </tbody>
        </table>
        <p className="muted">
          {estimate.flows
            ? "Estimated from measured pressure and the saved calibration. It is not a direct flow measurement."
            : `Flow estimate unavailable. ${estimate.reason}`}
        </p>
      </section>

      <section className="card">
        <h2>Printer position</h2>
        {duet.position ? (
          <dl className="readings">
            {Object.entries(duet.position).map(([axis, value]) => (
              <div key={axis}><dt>{axis}</dt><dd>{Number(value).toFixed(2)} mm</dd></div>
            ))}
          </dl>
        ) : (
          <p className="muted">No position available.</p>
        )}
        {state.print.predicted && (
          <>
            <h3>Sync script</h3>
            <dl className="readings">
              <div><dt>Predicted now</dt><dd>{state.print.predicted.current.map((v) => v.toFixed(1)).join(", ")}</dd></div>
              <div><dt>Looking ahead to</dt><dd>{state.print.predicted.future.map((v) => v.toFixed(1)).join(", ")}</dd></div>
              <div><dt>Sync marker</dt><dd>{state.print.predicted.sync}</dd></div>
            </dl>
          </>
        )}
      </section>

      <section className="card wide">
        <h2>Live log</h2>
        <div className="console-output" ref={logRef}>
          {log.length === 0 && <p className="muted">No log entries yet.</p>}
          {log.map((entry) => (
            <div key={entry.seq} className={`log-${entry.level}`}>
              {new Date(entry.time * 1000).toLocaleTimeString()} {entry.message}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
