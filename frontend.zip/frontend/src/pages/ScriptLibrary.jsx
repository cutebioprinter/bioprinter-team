export default function ScriptLibrary() {
  return (
    <section className="card">
      <h2>Script Library</h2>
      <p>Not built yet. This page will list, download and update scripts from GitHub.</p>
    </section>
  );
}
