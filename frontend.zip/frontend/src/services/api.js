export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(method, path, body) {
  let response;
  try {
    response = await fetch(`/api${path}`, {
      method,
      headers: body === undefined || body instanceof File ? undefined : { "Content-Type": "application/json" },
      body: body === undefined || body instanceof File ? body : JSON.stringify(body),
    });
  } catch {
    throw new ApiError("Cannot reach the Raspberry Pi.", 0);
  }

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = Array.isArray(data.detail) ? data.detail[0]?.msg : data.detail;
    throw new ApiError(detail || `Request failed (${response.status}).`, response.status);
  }
  return data;
}

export const api = {
  session: () => request("GET", "/session"),
  login: (password) => request("POST", "/login", { password }),
  logout: () => request("POST", "/logout"),
  purge: (channels, duration) => request("POST", "/ops/purge", { channels, duration }),
  sweep: () => request("POST", "/ops/sweep"),
  calibrate: (duration, tests) => request("POST", "/ops/calibrate", { duration, tests }),
  startTest: (pressures) => request("POST", "/ops/calibrate/start", { pressures }),
  saveResult: (weight_mg, composition) => request("POST", "/ops/calibrate/result", { weight_mg, composition }),
  repeatTest: () => request("POST", "/ops/calibrate/repeat"),
  listResults: () => request("GET", "/calibration/results"),
  deleteResult: (id) => request("DELETE", `/calibration/results/${id}`),
  calibrationModel: () => request("GET", "/calibration/model"),
  listJobs: () => request("GET", "/jobs"),
  uploadJob: (file, overwrite) =>
    request("POST", `/jobs?name=${encodeURIComponent(file.name)}&overwrite=${overwrite}`, file),
  checkJob: (name) => request("POST", "/jobs/check", { name }),
  startPrint: (name) => request("POST", "/print/start", { name }),
  stopPrint: () => request("POST", "/print/stop"),
  stop: () => request("POST", "/ops/stop"),
  gcode: (command) => request("POST", "/printer/gcode", { command }),
  emergencyStop: () => request("POST", "/printer/estop"),
  resetDuet: () => request("POST", "/printer/reset"),
};

/** Keeps a WebSocket open and reconnects. Returns a function that closes it. */
export function connectLive({ onState, onOpen, onClose, onAuthLost }) {
  let socket;
  let closed = false;
  let retry;

  function open() {
    const scheme = location.protocol === "https:" ? "wss" : "ws";
    socket = new WebSocket(`${scheme}://${location.host}/ws`);
    socket.onopen = onOpen;
    socket.onmessage = (event) => onState(JSON.parse(event.data));
    socket.onclose = (event) => {
      if (closed) return;
      if (event.code === 4401) {
        onAuthLost();
        return;
      }
      onClose();
      retry = setTimeout(open, 1000);
    };
  }

  open();
  return () => {
    closed = true;
    clearTimeout(retry);
    socket.close();
  };
}
