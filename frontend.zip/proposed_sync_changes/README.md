# Proposed sync changes (for evaluation)

Nothing here is in use. The GUI does not load this folder, and the bioprinter-team repository was not changed.

- `gcode_sync_volume.py` is a modified copy of `src/gcode_sync_volume.py`.
- `compare_prediction.py` compares the original and this copy on G-code files, with no hardware.

## How to evaluate

```bash
python compare_prediction.py /path/to/bioprinter-team 2.4
diff /path/to/bioprinter-team/src/gcode_sync_volume.py gcode_sync_volume.py
```

To run it without a pump, use `python gcode_sync_volume.py --gcode output.gcode --dry-run`. Dry run prints what it would do but does not read sync messages, so the first real check is a print with `--sync-lead 0`.

## What was found

Results use a flow rate of 2.4 µL/s and a dead volume of 25 µL. Each prediction check samples the first 80% of the print.

| File | Sync markers read (original → proposed) | Deposited volume in µL (original → proposed) | Predictions stuck at the end (original → proposed) | Average distance ahead in mm (original → proposed) |
|---|---|---|---|---|
| `tests/gcode/output.gcode` | 0 → 111 | 0 → 178.4 | 100% → 0% | 22.4 → 21.9 |
| `tests/gcode/output_sharpie.gcode` | 0 → 36 | 0 → 188.5 | 100% → 0% | 20.4 → 21.4 |
| `src/slicer/Shape-Cylinder.gcode` | 199 → 199 | 0 → 2292.4 | 100% → 0% | 190.7 → 4.3 |
| `examples/gcode/flowrateinttest.gcode` | 0 → 0 | 0 → 2292.4 | 100% → 0% | 191.5 → 4.3 |
| `examples/gcode/square_2s_per_side_duet3.gcode` | 0 → 5 | 0 → 19.2 | 100% → 100% | 21.8 → 21.8 |

`flowrateinttest.gcode` has no sync markers in the file. The square has only 19.2 µL in total, less than the 25 µL dead volume, so it stays at its last printed point in both versions, which is correct.

### 1. The lookahead never worked on these files

The original only counts a move as deposition if it has a positive `E` value. Our slicers do not write `E` values, and `postProcessPrusaSlicer.py` removes them. So deposited volume is always 0, and `get_position_after_volume` always returns the last point in the file. On Shape-Cylinder that is the `(200, 200, 0)` park position.

Every update therefore evaluates the gradient at one fixed point, so the commanded mix does not change during a print.

**Change:** added `--deposit-mode`. By default it uses `E` values if the file has them, then `@pump_pressure` messages (on when above 0), then G1 moves after the first sync marker.

### 2. Sync markers from the current slicer are not read

`bioprinter_slicer.ipynb` writes `M118 P0 S"12"`. The parser accepts `M118 S"@sync 12"` and `M118 12`, but not the `P0` form. It reads none of the 111 markers in `output.gcode`, so every message from the printer gets "not in the parsed G-code" and no update happens.

**Change:** the parser now accepts the `P` parameter.

### 3. The lookahead could aim at the park position

Near the end of a print, the original returns the file's final position.

**Change:** it now returns the last deposited point.

### 4. The flow rate default does not match the slicer

`TOTAL_FLOW_RATE` is 1.0, but `output.gcode` is sliced for 2.4 µL/s. That makes the lookahead look 2.4 times too far along the path.

**Change:** `--flow-rate` now defaults to the `Constant Volumetric Flowrate` line in the G-code header, if there is one. Files without that line, such as Shape-Cylinder, still need `--flow-rate`.

### 5. Sync messages probably arrive before the head gets there

Duet forum reports say M118 can be sent as the firmware reads the line, not when earlier moves finish, and that M400 makes it wait ([M400 vs G4 P0](https://forum.duet3d.com/topic/21795/m400-vs-g4-p0)). I could not confirm this in the official docs or on your firmware. `output.gcode` has no M400 or G4 before its markers, so the timeline may run ahead of the head by however long the queued moves take. Shape-Cylinder's 422 G4 lines stop the head, which avoids this for the markers right after them, but they aren't paired with its sync markers.

**Change:** added `--sync-lead`, in seconds, which defaults to 0 so nothing changes until you measure it. Adding M400 before each marker would make them accurate, but the head would stop at every marker while the pump keeps flowing.

## Not changed, worth deciding

- **Timing ignores acceleration.** Both versions treat every move as running at full speed. Using each file's M204 and M566 settings, `output.gcode` should take about 155 s rather than 83 s (1.88x). The others are 1.06x or less. This is an estimate from a simplified planner, not a measurement. `output.gcode` has about 13,900 moves, many only 0.02 to 0.08 mm long at 86 mm/s, which the head cannot reach. The script's `time_multiplier` corrects its overall pace at each marker, but not between them.
- **Over-deposition on short segments.** The slicer sets speed to give a constant flow. When the head cannot reach that speed and the pump flow stays constant, more material lands per mm, so those lines may come out wider than planned. Merging very short segments in the slicer would help timing and this.
- **Flow is treated as constant.** In `pump` mode, moves count as on or off, and all volume uses `--flow-rate`. The `@pump_pressure` values themselves are not used.
- **`R1`, `R2`, `R3` and `RN` are still placeholders.** The GUI's calibration page gives real values in mbar per µL/s, the same units as `--flow-rate` and `--dead-volume` here.

## Channel code left as it was

`send_pump_command` is unchanged here, as requested. It is worth one bench check, because it uses `(channel << 13) & 0x03`, which always gives 0. The sketch reads the channel from bits 5 and 6 of the first byte, so all three pressures may be landing on channel 0, with channel 2's value overwriting the others. With `--dry-run` off, watch whether channels 1 and 2 move during a print.
