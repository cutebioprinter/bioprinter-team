#!/usr/bin/env python3
"""Compare the original and proposed sync scripts on G-code files. Uses no hardware.

    python compare_prediction.py /path/to/bioprinter-team [flow rate]

Also estimates how long moves really take, using each file's own M204 acceleration
and M566 jerk, because both scripts time moves as if they run at full speed.
"""

import importlib.util
import math
import re
import sys
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = [
    "tests/gcode/output.gcode",
    "tests/gcode/output_sharpie.gcode",
    "src/slicer/Shape-Cylinder.gcode",
    "examples/gcode/flowrateinttest.gcode",
    "examples/gcode/square_2s_per_side_duet3.gcode",
]
DEAD_VOLUME = 25.0
SAMPLES = 200


def load(path, name):
    sys.modules.setdefault("serial", types.ModuleType("serial"))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def distance(a, b):
    return math.dist(a, b)


def lookahead_stats(engine, stop_pos):
    """How often the prediction lands on stop_pos, and how far it looks ahead."""
    total = engine.total_wall_time
    times = [total * 0.8 * i / SAMPLES for i in range(1, SAMPLES)]
    at_end = 0
    gaps = []
    for t in times:
        now = engine.get_position_at_wall_time(t)
        future = engine.get_position_after_volume(t, DEAD_VOLUME)
        at_end += distance(future, stop_pos) < 1e-6
        gaps.append(distance(now, future))
    return 100.0 * at_end / len(times), sum(gaps) / len(gaps)


def planned_time(path):
    """Estimate time with acceleration, using a forward and backward speed pass."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    accel_match = re.search(r"^M204\b.*?P(\d+)", text, re.M)
    jerk_match = re.search(r"^M566\s+X([\d.]+)\s+Y([\d.]+)\s+Z([\d.]+)", text, re.M)
    if not accel_match or not jerk_match:
        return None
    accel = float(accel_match.group(1))
    jerk = [float(v) / 60.0 for v in jerk_match.groups()]

    moves = []
    pos = [0.0, 0.0, 0.0]
    feed = 1000.0 / 60.0
    stop_next = False
    for raw in text.splitlines():
        line = raw.split(";", 1)[0].strip()
        if line.split()[:1] == ["G4"] or line.split()[:1] == ["M400"]:
            stop_next = True
            continue
        if not re.match(r"G0?[01]\b", line):
            continue
        new = list(pos)
        for axis, value in re.findall(r"([XYZF])(-?\d*\.?\d+)", line):
            if axis == "F":
                feed = float(value) / 60.0
            else:
                new["XYZ".index(axis)] = float(value)
        length = distance(pos, new)
        if length > 0:
            unit = [(new[i] - pos[i]) / length for i in range(3)]
            moves.append({"length": length, "unit": unit, "speed": feed, "stop_before": stop_next})
            stop_next = False
            pos = new

    count = len(moves)
    entry = [0.0] * (count + 1)
    for i in range(1, count):
        before, after = moves[i - 1], moves[i]
        if after["stop_before"]:
            continue
        limit = min(before["speed"], after["speed"])
        for axis in range(3):
            change = abs(before["unit"][axis] - after["unit"][axis])
            if change * limit > jerk[axis]:
                limit = jerk[axis] / change
        entry[i] = limit
    for i in range(count - 1, -1, -1):
        entry[i] = min(entry[i], math.sqrt(entry[i + 1] ** 2 + 2 * accel * moves[i]["length"]))
    for i in range(count):
        entry[i + 1] = min(entry[i + 1], math.sqrt(entry[i] ** 2 + 2 * accel * moves[i]["length"]))

    ideal = planned = 0.0
    for i, move in enumerate(moves):
        start, end, length = entry[i], entry[i + 1], move["length"]
        top = math.sqrt((2 * accel * length + start**2 + end**2) / 2)
        top = min(top, move["speed"])
        up = (top**2 - start**2) / (2 * accel)
        down = (top**2 - end**2) / (2 * accel)
        planned += (top - start) / accel + (top - end) / accel + max(0.0, length - up - down) / top
        ideal += length / move["speed"]
    return ideal, planned


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    repo = Path(sys.argv[1])
    flow = float(sys.argv[2]) if len(sys.argv) > 2 else 2.4
    original = load(repo / "src" / "gcode_sync_volume.py", "original_sync")
    proposed = load(HERE / "gcode_sync_volume.py", "proposed_sync")

    for relative in FILES:
        path = repo / relative
        old = original.GCodeKinematicsEngine(flow)
        old.parse_gcode_file(str(path))
        new = proposed.GCodeKinematicsEngine(flow)
        new.parse_gcode_file(str(path))

        print(f"\n{relative}")
        print(f"  sync markers read:   original {len(old.seq_times):4d}   proposed {len(new.seq_times):4d}")
        print(f"  volume deposited:    original {old.total_print_volume:7.1f}   proposed {new.total_print_volume:7.1f}")
        share, gap = lookahead_stats(old, old.final_pos)
        print(f"  original prediction: {share:5.1f}% of samples at the file's last point, average {gap:6.1f} mm ahead")
        share, gap = lookahead_stats(new, new.final_deposit_pos or new.final_pos)
        print(f"  proposed prediction: {share:5.1f}% of samples at the last printed point, average {gap:6.1f} mm ahead")

        times = planned_time(path)
        if times:
            ideal, planned = times
            print(f"  full-speed time {ideal:7.1f} s, with acceleration {planned:7.1f} s ({planned / ideal:.2f}x)")


if __name__ == "__main__":
    main()
