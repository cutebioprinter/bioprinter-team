#!/usr/bin/env python3
"""Pump sine-wave test for the Raspberry Pi 5 (Arduino pump over USB).

Usage:
    python3 pump_test_pi.py --list-ports            Show USB serial devices; sends nothing
    python3 pump_test_pi.py                         Find the Uno automatically and run
    python3 pump_test_pi.py --port /dev/ttyACM1     Use a specific port
    python3 pump_test_pi.py --duration 30           Stop by itself after 30 seconds

Press Ctrl+C to stop. All channels are commanded to 0 mbar on exit.
"""

import argparse
import math
import os
import signal
import sys
import time

import serial
from serial.tools import list_ports

# ---------------------------------- Settings ----------------------------------

# Which USB port the pump is on. Leave as "auto" to find the Uno on any socket,
# or set a path such as "/dev/ttyACM1" or "/dev/serial/by-id/usb-Arduino...".
# Can also be set with --port or the PUMP_PORT environment variable.
# Priority: --port, then PUMP_PORT, then this value.
PUMP_PORT = "auto"

BAUDRATE = 115200
MAX_PRESSURE_MBAR = 2068
CHANNELS = (0, 1, 2)  # The pump sketch ignores channel 3

ARDUINO_RESET_S = 2.0  # Opening the USB port resets the Uno

# USB vendor IDs that auto-detect accepts as the Uno.
ARDUINO_USB_VIDS = {
    0x2341: "Arduino",
    0x2A03: "Arduino",
    0x1A86: "CH340 (Uno clone)",
}

# The Duet is also a USB serial device (usually /dev/ttyACM*). Never send it
# pump bytes, even if its port is chosen by hand.
DUET_USB_VIDS = {0x1D50}

# Sine test: each channel swings between 0 and 2000 mbar.
PERIOD_S = 20.0
AMPLITUDE_MBAR = 1000
OFFSET_MBAR = 1000
UPDATE_INTERVAL_S = 0.1  # 10 Hz


# --------------------------------- Port lookup ---------------------------------

def stable_links(device):
    """Return /dev/serial symlinks for a device. Linux only; [] elsewhere."""
    links = []
    for folder in ("/dev/serial/by-id", "/dev/serial/by-path"):
        if os.path.isdir(folder):
            for name in sorted(os.listdir(folder)):
                path = os.path.join(folder, name)
                if os.path.realpath(path) == os.path.realpath(device):
                    links.append(path)
    return links


def kind_of(port):
    if port.vid in DUET_USB_VIDS:
        return "Duet (not the pump)"
    if port.vid in ARDUINO_USB_VIDS:
        return ARDUINO_USB_VIDS[port.vid]
    return "unknown"


def print_ports(ports):
    if not ports:
        print("No USB serial devices found.")
    for port in ports:
        ids = f"{port.vid:04X}:{port.pid:04X}" if port.vid is not None else "no USB ID"
        print(f"{port.device}  [{ids}]  {kind_of(port)}  {port.description}")
        for link in stable_links(port.device):
            print(f"    {link}")


def resolve_port(requested, ports=None):
    """Turn "auto" or a path into the port to open, or exit with an explanation."""
    ports = list(list_ports.comports() if ports is None else ports)

    if requested != "auto":
        if "://" in requested:  # pyserial test URL such as loop://
            return requested
        target = os.path.realpath(requested)
        for port in ports:
            if os.path.realpath(port.device) == target and port.vid in DUET_USB_VIDS:
                sys.exit(f"Refusing to use {requested}: it is the Duet, not the pump.")
        return requested

    matches = [port for port in ports if port.vid in ARDUINO_USB_VIDS]
    if len(matches) == 1:
        return matches[0].device

    print_ports(ports)
    problem = "No Arduino found" if not matches else "More than one Arduino found"
    sys.exit(f"{problem}. Choose one with --port or PUMP_PORT.")


# ------------------------------- Pump controller -------------------------------

class PumpController:
    def __init__(self, port, baudrate=BAUDRATE):
        self.ser = serial.serial_for_url(
            port, baudrate, timeout=0.1, write_timeout=1, exclusive=True
        )
        self._rx = b""
        time.sleep(ARDUINO_RESET_S)
        self.ser.reset_input_buffer()

    def set_pressure(self, channel, pressure):
        """Send a 2-byte command. Frame: 0ccppppp 1ppppppp, high bits first.

        Bytes match debugPrinter.py's send_pump_command for all valid values.
        """
        channel = int(channel)
        if channel not in CHANNELS:
            raise ValueError(f"Invalid pump channel: {channel}")
        if not math.isfinite(pressure):
            raise ValueError(f"Invalid pressure: {pressure}")
        pressure = max(0, min(MAX_PRESSURE_MBAR, int(pressure)))

        high_byte = (channel << 5) | ((pressure >> 7) & 0x1F)
        low_byte = 0x80 | (pressure & 0x7F)
        self.ser.write(bytes([high_byte, low_byte]))

    def read_feedback(self):
        """Return the newest complete feedback line as a list of fields, or None."""
        waiting = self.ser.in_waiting
        if waiting:
            self._rx = (self._rx + self.ser.read(waiting))[-4096:]
        if b"\n" not in self._rx:
            return None

        *lines, self._rx = self._rx.split(b"\n")  # Keep any partial line for next time
        for line in reversed(lines):
            text = line.decode("utf-8", errors="ignore").strip()
            if text:
                return text.split(",")
        return None

    def zero_all(self):
        """Command 0 mbar on every channel. Returns False if that could not be sent."""
        try:
            for channel in CHANNELS:
                self.set_pressure(channel, 0)
            self.ser.flush()
            return True
        except (serial.SerialException, OSError):
            return False

    def close(self):
        self.ser.close()


# ---------------------------------- Sine test ----------------------------------

def stop_on_signal(signum, frame):
    raise KeyboardInterrupt


def ignore_stop_signals():
    """Keep a second Ctrl+C from interrupting the shutdown commands."""
    for name in ("SIGINT", "SIGTERM", "SIGHUP"):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), signal.SIG_IGN)


def sine_pressures(t):
    omega = (2 * math.pi) / PERIOD_S
    # Channel 0 starts at 0 mbar; channels 1 and 2 start at 1866 and 133 mbar.
    p0 = int(-AMPLITUDE_MBAR * math.cos(omega * t) + OFFSET_MBAR)
    p1 = int(AMPLITUDE_MBAR * math.sin(omega * t + (2 * math.pi / 3)) + OFFSET_MBAR)
    p2 = int(AMPLITUDE_MBAR * math.sin(omega * t + (4 * math.pi / 3)) + OFFSET_MBAR)
    return p0, p1, p2


def run_sine_test(pump, duration=None):
    start_time = time.monotonic()
    next_update = start_time

    while True:
        t = time.monotonic() - start_time
        if duration is not None and t >= duration:
            return

        p0, p1, p2 = sine_pressures(t)
        pump.set_pressure(0, p0)
        pump.set_pressure(1, p1)
        pump.set_pressure(2, p2)

        feedback = pump.read_feedback()
        feedback_str = f"Measured: {feedback} mbar" if feedback else "Sensor: No Data"
        print(f"Time: {t:05.1f}s | Cmd: [{p0:4d}, {p1:4d}, {p2:4d}] mbar | {feedback_str}")

        next_update += UPDATE_INTERVAL_S
        time.sleep(max(0.0, next_update - time.monotonic()))


# ------------------------------------ Main -------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Pump sine-wave test (Arduino over USB)")
    parser.add_argument("--port", help='serial port, or "auto" to find the Uno')
    parser.add_argument("--list-ports", action="store_true",
                        help="show USB serial devices and exit; sends nothing")
    parser.add_argument("--duration", type=float, help="stop after this many seconds")
    parser.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    args = parser.parse_args()

    if args.list_ports:
        print_ports(list(list_ports.comports()))
        return 0

    port = resolve_port(args.port or os.environ.get("PUMP_PORT") or PUMP_PORT)

    print(f"Pump port: {port}")
    print(f"This applies up to {AMPLITUDE_MBAR + OFFSET_MBAR} mbar to channels 0, 1 and 2.")
    if not args.yes:
        try:
            answer = input("Type 'yes' to start: ")
        except EOFError:
            answer = ""
        if answer.strip().lower() != "yes":
            print("Cancelled. Nothing was sent.")
            return 0

    try:
        pump = PumpController(port)
    except PermissionError:
        sys.exit(f"No permission for {port}. Run: sudo usermod -aG dialout $USER, then log in again.")
    except (serial.SerialException, OSError) as exc:
        sys.exit(f"Could not open {port}: {exc}\nIs another program using it? "
                 "Try --list-ports to see what is connected.")

    print("Connected to pump. Press Ctrl+C to stop.")
    for name in ("SIGTERM", "SIGHUP"):  # systemd stop, or a dropped SSH session
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), stop_on_signal)

    exit_code = 0
    try:
        run_sine_test(pump, args.duration)
    except KeyboardInterrupt:
        print("\nStopping loop and turning off pumps...")
    except (serial.SerialException, OSError) as exc:
        print(f"\nSerial error: {exc}", file=sys.stderr)
        exit_code = 1
    finally:
        ignore_stop_signals()
        zeroed = pump.zero_all()
        time.sleep(0.5)
        pump.close()

    if not zeroed:
        print("WARNING: could not command 0 mbar. Pressure may still be applied. "
              "Check the pump now.", file=sys.stderr)
        return 1
    print("All channels commanded to 0 mbar. Connection closed.")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
